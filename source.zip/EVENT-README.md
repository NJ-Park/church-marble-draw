# 교회 행사 구슬 추첨 — 로컬 시제품

**2차 개발 안내:** QR·Supabase 연결용 구현은 `CLOUD-README.md`를 참고하세요. 아래 내용은 인터넷 없이 사용하는 `event.html`의 범위입니다.

기준 upstream: lazygyu/roulette `e9a9d22b040d3acf8f7b581285d1dd39bbe9c2b1`.
원본 README와 LICENSE는 유지했습니다. 행사 앱의 진입점은 `event.html`입니다.

## 실행

검증 환경: Node 24.22.1, pnpm 11.25.0, macOS arm64.

```sh
pnpm install --frozen-lockfile --shamefully-hoist --ignore-scripts
pnpm typecheck:event
pnpm test:event
pnpm build:event
python3 -m http.server 1235 --bind 127.0.0.1 --directory dist-local
```

브라우저에서 http://127.0.0.1:1235/event.html 을 엽니다. 별도 다운로드의 빌드 실행본은 패키지 설치 없이 해당 폴더에서 Python 정적 서버만 실행하면 됩니다. 파일을 더블 클릭해 `file://`로 열면 WebAssembly/동기화 기능이 동작하지 않을 수 있습니다.

1. 빈 명단에서 ‘300명 테스트 명단’을 누르거나 이름을 줄 단위로 추가합니다.
2. ‘방송 화면 열기’를 눌러 같은 브라우저에서 방송 화면을 별도 창으로 엽니다.
3. 방송 화면을 보이는 창으로 유지하고, 진행자 화면에서 맵·방식·인원을 선택해 시작합니다.
4. 결과가 기록되면 다음 회차를 진행합니다. 당첨자 제외 옵션이 켜져 있으면 추첨 가능 인원이 줄어듭니다.
5. 명단의 상태 버튼으로 개별 제외/복귀가 가능합니다. 진행 중에는 명단·설정을 변경하지 못합니다.

## 구현 범위

- 참가자 UUID와 표시 이름 분리. 최대 300명, 동명이인 허용, 원본 이름 문법으로 구슬 수가 증가하지 않음.
- 선착순/최후 생존, 복수 당첨, 회차 snapshot, 당첨자 제외 및 이력.
- 진행자와 방송 화면 분리. 동일 origin BroadcastChannel 동기화, 로컬 저장, Web Locks로 방송 실행 화면 1개 제한.
- 추첨 도중 방송 새로고침 시 중단. 같은 회차를 자동 재실행하지 않음.
- 원본 맵·Box2D 구현·Canvas 렌더러 유지. 행사 경로의 광고/원격 키워드 요청 제거. 스킬·녹화 기본 꺼짐.
- 라이선스 전문과 원본 출처 표시.

## 제한

QR/휴대폰 등록, Supabase, 진행자 인증, 원격 기기 동기화, 서버 측 정원·권한 검증, 서버 lease와 감사 로그는 아직 구현하지 않았습니다. 한 컴퓨터·동일 브라우저·진행자 1명 조건의 로컬 개발 시제품입니다. localStorage와 브라우저 메시지는 신뢰 경계가 아니므로 실제 접수/경품 운영에 사용하지 마세요. 새 시크릿 창은 테스트 명단을 별도로 시작하는 데 사용할 수 있습니다.

운영 화면과 방송 화면을 서로 다른 모니터의 **보이는 창**으로 유지해야 합니다. 숨겨진 탭은 브라우저에 의해 느려질 수 있습니다. 결과가 저장된 뒤 방송을 새로고침하면 게임 장면은 재생하지 않으며 이력은 진행자 화면에 남습니다.

세부 결과와 다음 구현 계획은 `docs/검증결과와-구현계획.md`를 참고하세요.

## 검증 도구

- `pnpm benchmark:event`: 원본 시뮬레이션 기반 4맵 × 100/300명 × 3시드 물리 검증 JSON.
- `node scripts/build-portable.cjs benchmark.html`: 브라우저 성능 측정 화면 빌드. 측정 종료 후 JSON을 화면에 표시합니다.
- `scripts/build-portable.cjs`: Parcel 공식 FSCache 사용. 이 환경에서 기본 LMDB 캐시가 제한되어 파일 캐시로 빌드합니다. `EVENT_DIST` 환경변수로 출력 폴더를 지정할 수 있습니다.
- `pnpm test:event`: 회차 규칙/결과 검증 6건과 엔진 ID/최후 생존 3건.

원본 `index.html`, 기존 dev/build 명령은 비교용으로 남아 있습니다. 행사 배포에는 `build:event` 산출물을 사용하세요.
