-- Per-event QR admission is independent of manual imports and registration closing.
alter table public.cd_events add column if not exists qr_enabled boolean not null default true;
create or replace function public.cd_set_qr_enabled(eid uuid, is_enabled boolean) returns void
language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 if is_enabled is null then raise exception 'INVALID_QR_SETTING'; end if;
 update public.cd_events set qr_enabled=is_enabled where id=eid;
 perform cd_private.touch(eid,'qr_enabled',jsonb_build_object('enabled',is_enabled));
end $$;
revoke all on function public.cd_set_qr_enabled(uuid,boolean) from public,anon,authenticated;
grant execute on function public.cd_set_qr_enabled(uuid,boolean) to authenticated;

create or replace function public.cd_event_info(code text) returns jsonb language plpgsql security definer set search_path='' as $$
declare e public.cd_events;
begin
 select ev.* into e from public.cd_events ev join cd_private.secrets s on s.event_id=ev.id where s.join_code=code;
 if e.id is null then raise exception 'EVENT_NOT_FOUND'; end if;
 return jsonb_build_object('id',e.id,'title',e.title,'open',(e.registration_open and e.qr_enabled),'qrEnabled',e.qr_enabled,'capacity',e.capacity,
 'registered',(select count(*) from cd_private.participants where event_id=e.id));
end $$;
create or replace function public.cd_register(code text, display_name text) returns jsonb language plpgsql security definer set search_path='' as $$
declare eid uuid; e public.cd_events; p cd_private.participants; total integer; clean text;
begin
 if auth.uid() is null then raise exception 'LOGIN_REQUIRED'; end if;
 select event_id into eid from cd_private.secrets where join_code=code;
 select * into e from public.cd_events where id=eid for update;
 if e.id is null then raise exception 'EVENT_NOT_FOUND'; end if;
 select * into p from cd_private.participants where event_id=eid and user_id=auth.uid();
 if p.id is not null then return jsonb_build_object('id',p.id,'name',p.name,'number',p.number,'existing',true); end if;
 if not e.qr_enabled then raise exception 'QR_DISABLED'; end if;
 if not e.registration_open then raise exception 'REGISTRATION_CLOSED'; end if;
 clean:=cd_private.clean_name(display_name);
 select count(*) into total from cd_private.participants where event_id=eid;
 if total>=e.capacity then raise exception 'CAPACITY_REACHED'; end if;
 insert into cd_private.participants(event_id,user_id,number,name) values(eid,auth.uid(),total+1,clean) returning * into p;
 perform cd_private.touch(eid,'register',jsonb_build_object('participant',p.id));
 return jsonb_build_object('id',p.id,'name',p.name,'number',p.number,'existing',false);
end $$;
