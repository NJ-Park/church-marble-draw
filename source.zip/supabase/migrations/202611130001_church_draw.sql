-- Apply once to a NEW Supabase development project. No existing objects are dropped.
-- All writes go through authorized RPCs; Realtime publishes only an event revision.
begin;
create schema cd_private;
revoke all on schema cd_private from public, anon, authenticated;

create table public.cd_events (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id),
 title text not null check(char_length(title) between 1 and 80),
 capacity integer not null default 300 check(capacity between 1 and 300),
 registration_open boolean not null default true, revision bigint not null default 0,
 created_at timestamptz not null default now()
);
create table cd_private.secrets (
 event_id uuid primary key references public.cd_events(id) on delete cascade,
 join_code text unique not null default replace(gen_random_uuid()::text,'-',''),
 pair_code text unique, pair_expires timestamptz
);
create table cd_private.displays (
 event_id uuid primary key references public.cd_events(id) on delete cascade,
 user_id uuid not null references auth.users(id), seen_at timestamptz, session_id uuid
);
create table cd_private.participants (
 id uuid primary key default gen_random_uuid(), event_id uuid not null references public.cd_events(id) on delete cascade,
 user_id uuid references auth.users(id), number integer not null, name text not null,
 excluded boolean not null default false, created_at timestamptz not null default now(),
 unique(event_id,user_id), unique(event_id,number), check(char_length(name) between 1 and 30)
);
create table cd_private.rounds (
 id uuid primary key default gen_random_uuid(), event_id uuid not null references public.cd_events(id) on delete cascade,
 number integer not null, request_id uuid not null,
 mode text not null check(mode in ('first','last')), winner_count integer not null check(winner_count between 1 and 300),
 map_index integer not null check(map_index between 0 and 3), exclude_winners boolean not null,
 status text not null default 'prepared' check(status in ('prepared','running','completed','cancelled','interrupted')),
 entries jsonb not null, winner_ids uuid[], engine_version text not null default 'e9a9d22-event-v2',
 renderer_id uuid, session_id uuid, execution_token uuid, lease_until timestamptz,
 created_at timestamptz not null default now(), completed_at timestamptz,
 unique(event_id,number), unique(event_id,request_id)
);
create unique index cd_one_active_round on cd_private.rounds(event_id) where status in ('prepared','running');
create table cd_private.imports (
 event_id uuid references public.cd_events(id) on delete cascade, request_id uuid, names jsonb not null,
 primary key(event_id,request_id)
);
create table cd_private.audit (
 id bigint generated always as identity primary key, event_id uuid references public.cd_events(id) on delete cascade,
 actor uuid, action text not null, detail jsonb, created_at timestamptz not null default now()
);

create function cd_private.owner(eid uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from public.cd_events where id=eid and owner_id=auth.uid()) then
  raise exception 'FORBIDDEN';
 end if;
end $$;
create function cd_private.display(eid uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from cd_private.displays where event_id=eid and user_id=auth.uid()) then
  raise exception 'DISPLAY_FORBIDDEN';
 end if;
end $$;
create function cd_private.clean_name(value text) returns text language plpgsql immutable set search_path='' as $$
declare result text := btrim(normalize(value,NFC));
begin
 if result is null or char_length(result) not between 1 and 30 or result ~ '[[:cntrl:]]'
    or result ~ U&'[\00AD\061C\200B-\200F\202A-\202E\2060-\206F\FEFF]' then raise exception 'INVALID_NAME'; end if;
 return result;
end $$;
create function cd_private.touch(eid uuid, action_name text, data jsonb default '{}'::jsonb) returns void language plpgsql security definer set search_path='' as $$
begin
 update public.cd_events set revision=revision+1 where id=eid;
 insert into cd_private.audit(event_id,actor,action,detail) values(eid,auth.uid(),action_name,data);
end $$;
create function cd_private.round_json(r cd_private.rounds) returns jsonb language sql stable set search_path='' as $$
 select jsonb_build_object('id',r.id,'requestId',r.request_id,'number',r.number,'mode',r.mode,'count',r.winner_count,'map',r.map_index,
 'excludeWinners',r.exclude_winners,'status',r.status,'entries',r.entries,'winnerIds',r.winner_ids,
 'engineVersion',r.engine_version,'createdAt',r.created_at,'completedAt',r.completed_at);
$$;

create function public.cd_can_read_event(eid uuid) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and (exists(select 1 from public.cd_events where id=eid and owner_id=auth.uid())
 or exists(select 1 from cd_private.displays where event_id=eid and user_id=auth.uid()));
$$;
alter table public.cd_events enable row level security;
create policy cd_read_event on public.cd_events for select to authenticated using(public.cd_can_read_event(id));
revoke all on public.cd_events from public,anon,authenticated;
grant select on public.cd_events to authenticated;
-- Private tables also have RLS with no client policies (defence in depth).
alter table cd_private.secrets enable row level security;
alter table cd_private.displays enable row level security;
alter table cd_private.participants enable row level security;
alter table cd_private.rounds enable row level security;
alter table cd_private.imports enable row level security;
alter table cd_private.audit enable row level security;

create function public.cd_create_event(event_title text, max_people integer default 300) returns uuid language plpgsql security definer set search_path='' as $$
declare eid uuid;
begin
 if auth.uid() is null or coalesce((auth.jwt()->>'is_anonymous')::boolean,true) then raise exception 'HOST_LOGIN_REQUIRED'; end if;
 insert into public.cd_events(owner_id,title,capacity) values(auth.uid(),btrim(event_title),max_people) returning id into eid;
 insert into cd_private.secrets(event_id) values(eid);
 perform cd_private.touch(eid,'create_event'); return eid;
end $$;

create function public.cd_event_info(code text) returns jsonb language plpgsql security definer set search_path='' as $$
declare e public.cd_events;
begin
 select ev.* into e from public.cd_events ev join cd_private.secrets s on s.event_id=ev.id where s.join_code=code;
 if e.id is null then raise exception 'EVENT_NOT_FOUND'; end if;
 return jsonb_build_object('id',e.id,'title',e.title,'open',e.registration_open,'capacity',e.capacity,
 'registered',(select count(*) from cd_private.participants where event_id=e.id));
end $$;
create function public.cd_register(code text, display_name text) returns jsonb language plpgsql security definer set search_path='' as $$
declare eid uuid; e public.cd_events; p cd_private.participants; total integer; clean text;
begin
 if auth.uid() is null then raise exception 'LOGIN_REQUIRED'; end if;
 select event_id into eid from cd_private.secrets where join_code=code;
 select * into e from public.cd_events where id=eid for update;
 if e.id is null then raise exception 'EVENT_NOT_FOUND'; end if;
 select * into p from cd_private.participants where event_id=eid and user_id=auth.uid();
 if p.id is not null then return jsonb_build_object('id',p.id,'name',p.name,'number',p.number,'existing',true); end if;
 if not e.registration_open then raise exception 'REGISTRATION_CLOSED'; end if;
 clean:=cd_private.clean_name(display_name);
 select count(*) into total from cd_private.participants where event_id=eid;
 if total>=e.capacity then raise exception 'CAPACITY_REACHED'; end if;
 insert into cd_private.participants(event_id,user_id,number,name) values(eid,auth.uid(),total+1,clean) returning * into p;
 perform cd_private.touch(eid,'register',jsonb_build_object('participant',p.id));
 return jsonb_build_object('id',p.id,'name',p.name,'number',p.number,'existing',false);
end $$;
create function public.cd_set_registration(eid uuid, is_open boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 update public.cd_events set registration_open=is_open where id=eid;
 perform cd_private.touch(eid,'registration',jsonb_build_object('open',is_open));
end $$;
create function public.cd_import(eid uuid, request_key uuid, names text[]) returns void language plpgsql security definer set search_path='' as $$
declare total integer; cap integer; name_value text; previous jsonb;
begin
 perform cd_private.owner(eid); select capacity into cap from public.cd_events where id=eid for update;
 select i.names into previous from cd_private.imports i where event_id=eid and request_id=request_key;
 if previous is not null then
  if previous<>to_jsonb(names) then raise exception 'REQUEST_CONFLICT'; end if; return;
 end if;
 if request_key is null or names is null or cardinality(names) not between 1 and 300 then raise exception 'INVALID_NAMES'; end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 select count(*) into total from cd_private.participants where event_id=eid;
 if total+cardinality(names)>cap then raise exception 'CAPACITY_REACHED'; end if;
 foreach name_value in array names loop
  total:=total+1;
  insert into cd_private.participants(event_id,number,name) values(eid,total,cd_private.clean_name(name_value));
 end loop;
 insert into cd_private.imports values(eid,request_key,to_jsonb(names));
 perform cd_private.touch(eid,'import',jsonb_build_object('count',cardinality(names)));
end $$;
create function public.cd_exclude(eid uuid, participant_id uuid, is_excluded boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 update cd_private.participants set excluded=is_excluded where event_id=eid and id=participant_id;
 if not found then raise exception 'PARTICIPANT_NOT_FOUND'; end if;
 perform cd_private.touch(eid,'exclude',jsonb_build_object('participant',participant_id,'excluded',is_excluded));
end $$;
create function public.cd_rotate_display(eid uuid) returns text language plpgsql security definer set search_path='' as $$
declare code text:=replace(gen_random_uuid()::text,'-','');
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 delete from cd_private.displays where event_id=eid;
 update cd_private.secrets set pair_code=code,pair_expires=clock_timestamp()+interval '10 minutes' where event_id=eid;
 perform cd_private.touch(eid,'rotate_display'); return code;
end $$;
create function public.cd_pair_display(eid uuid, code text) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'LOGIN_REQUIRED'; end if;
 perform 1 from public.cd_events where id=eid for update;
 if not exists(select 1 from cd_private.secrets where event_id=eid and pair_code=code and pair_expires>clock_timestamp()) then raise exception 'INVALID_PAIR_CODE'; end if;
 insert into cd_private.displays(event_id,user_id) values(eid,auth.uid());
 update cd_private.secrets set pair_code=null,pair_expires=null where event_id=eid;
 perform cd_private.touch(eid,'pair_display');
end $$;
create function public.cd_heartbeat(eid uuid, sid uuid) returns boolean language plpgsql security definer set search_path='' as $$
declare r cd_private.rounds;
begin
 perform cd_private.display(eid); perform 1 from public.cd_events where id=eid for update;
 if sid is null then raise exception 'INVALID_SESSION'; end if;
 update cd_private.displays set seen_at=clock_timestamp(),session_id=sid where event_id=eid and user_id=auth.uid();
 select * into r from cd_private.rounds where event_id=eid and status='running';
 if r.id is null then return true; end if;
 if r.renderer_id<>auth.uid() or r.session_id<>sid then return false; end if;
 if r.lease_until<=clock_timestamp() then
  update cd_private.rounds set status='interrupted' where id=r.id;
  perform cd_private.touch(eid,'lease_expired',jsonb_build_object('round',r.id)); return false;
 end if;
 update cd_private.rounds set lease_until=clock_timestamp()+interval '30 seconds' where id=r.id;
 return true;
end $$;
create function public.cd_prepare(eid uuid, request_key uuid, draw_mode text, winner_count integer, map_index integer, exclude_winners boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare r cd_private.rounds; entries jsonb; next_number integer; total integer;
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 select * into r from cd_private.rounds where event_id=eid and request_id=request_key;
 if r.id is not null then
  if r.mode is distinct from draw_mode or r.winner_count is distinct from winner_count or r.map_index is distinct from map_index or r.exclude_winners is distinct from exclude_winners then raise exception 'REQUEST_CONFLICT'; end if;
  return r.id;
 end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 if not exists(select 1 from cd_private.displays where event_id=eid and seen_at>clock_timestamp()-interval '15 seconds') then raise exception 'DISPLAY_OFFLINE'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'number',number) order by number),'[]'::jsonb), count(*) into entries,total from cd_private.participants where event_id=eid and not excluded;
 if total=0 or winner_count is null or winner_count<1 or winner_count>total then raise exception 'INVALID_COUNT'; end if;
 select coalesce(max(number),0)+1 into next_number from cd_private.rounds where event_id=eid;
 insert into cd_private.rounds(event_id,number,request_id,mode,winner_count,map_index,exclude_winners,entries)
 values(eid,next_number,request_key,draw_mode,winner_count,map_index,exclude_winners,entries) returning * into r;
 perform cd_private.touch(eid,'prepare',jsonb_build_object('round',r.id)); return r.id;
end $$;
create function public.cd_claim(eid uuid, rid uuid, sid uuid, version text) returns uuid language plpgsql security definer set search_path='' as $$
declare r cd_private.rounds; token uuid;
begin
 perform cd_private.display(eid); perform 1 from public.cd_events where id=eid for update;
 select * into r from cd_private.rounds where event_id=eid and id=rid;
 if r.id is null or sid is null then raise exception 'ROUND_NOT_FOUND'; end if;
 if r.engine_version is distinct from version then raise exception 'ENGINE_VERSION_MISMATCH'; end if;
 if r.status='running' and r.renderer_id=auth.uid() and r.session_id=sid and r.lease_until>clock_timestamp() then return r.execution_token; end if;
 if r.status<>'prepared' then raise exception 'ROUND_ALREADY_CLAIMED'; end if;
 token:=gen_random_uuid();
 update cd_private.rounds set status='running',renderer_id=auth.uid(),session_id=sid,execution_token=token,lease_until=clock_timestamp()+interval '30 seconds' where id=rid;
 perform cd_private.touch(eid,'claim',jsonb_build_object('round',rid)); return token;
end $$;
create function public.cd_finish(eid uuid, rid uuid, sid uuid, token uuid, winners uuid[]) returns void language plpgsql security definer set search_path='' as $$
declare r cd_private.rounds;
begin
 perform cd_private.display(eid); perform 1 from public.cd_events where id=eid for update;
 select * into r from cd_private.rounds where event_id=eid and id=rid;
 if r.id is null or r.renderer_id is distinct from auth.uid() or r.session_id is distinct from sid or r.execution_token is distinct from token then raise exception 'EXECUTION_FORBIDDEN'; end if;
 if r.status='completed' then
  if r.winner_ids is distinct from winners then raise exception 'RESULT_CONFLICT'; end if; return;
 end if;
 if r.status<>'running' or r.lease_until<=clock_timestamp() then raise exception 'LEASE_EXPIRED_OR_CANCELLED'; end if;
 if winners is null or cardinality(winners)<>r.winner_count or
   (select count(distinct x) from unnest(winners) x)<>r.winner_count or
   exists(select 1 from unnest(winners) x where not exists(select 1 from jsonb_array_elements(r.entries) e where (e->>'id')::uuid=x)) then raise exception 'INVALID_WINNERS'; end if;
 update cd_private.rounds set winner_ids=winners,status='completed',completed_at=clock_timestamp() where id=rid;
 if r.exclude_winners then update cd_private.participants set excluded=true where event_id=eid and id=any(winners); end if;
 perform cd_private.touch(eid,'finish',jsonb_build_object('round',rid,'winners',winners));
end $$;
create function public.cd_cancel(eid uuid, rid uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 update cd_private.rounds set status='cancelled' where event_id=eid and id=rid and status in ('prepared','running','interrupted');
 if found then perform cd_private.touch(eid,'cancel',jsonb_build_object('round',rid)); end if;
end $$;
create function public.cd_host_snapshot(eid uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform cd_private.owner(eid);
 select jsonb_build_object('event',to_jsonb(e),'joinCode',s.join_code,
 'displayReady',exists(select 1 from cd_private.displays where event_id=eid and seen_at>clock_timestamp()-interval '15 seconds'),
 'participants',(select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'number',number,'excluded',excluded) order by number),'[]'::jsonb) from cd_private.participants where event_id=eid),
 'rounds',(select coalesce(jsonb_agg(cd_private.round_json(r) order by r.number desc),'[]'::jsonb) from (select * from cd_private.rounds where event_id=eid order by number desc limit 50) r))
 into result from public.cd_events e join cd_private.secrets s on s.event_id=e.id where e.id=eid;
 return result;
end $$;
create function public.cd_display_snapshot(eid uuid) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.display(eid);
 return jsonb_build_object('event',(select to_jsonb(e)-'owner_id' from public.cd_events e where id=eid),
 'round',(select cd_private.round_json(r) from cd_private.rounds r where event_id=eid order by number desc limit 1));
end $$;

-- Revoke default PUBLIC function execution, then grant only explicit app endpoints.
revoke all on all functions in schema cd_private from public,anon,authenticated;
do $$ declare f record; begin
 for f in select p.oid::regprocedure as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname like 'cd\_%' escape '\' loop
  execute format('revoke all on function %s from public, anon, authenticated',f.signature);
  execute format('grant execute on function %s to authenticated',f.signature);
 end loop;
end $$;
grant execute on function public.cd_event_info(text) to anon;
commit;
