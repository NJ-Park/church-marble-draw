alter table public.cd_events add column if not exists lobby_map integer not null default 0 check(lobby_map between 0 and 3);
create or replace function public.cd_set_map(eid uuid, map_index integer)
returns void language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 if map_index is null or map_index not between 0 and 3 then raise exception 'INVALID_SHUFFLE'; end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 update public.cd_events set lobby_map=map_index where id=eid;
 perform cd_private.touch(eid,'set_map');
end $$;
-- Only paired displays/owners can read the waiting roster. No names enter the public event table.
create or replace function cd_private.lobby_json(eid uuid)
returns jsonb language sql stable set search_path='' as $$
 select jsonb_build_object('map',e.lobby_map,'entries',(
  select coalesce(jsonb_agg(jsonb_build_object('id',p.id,'name',p.name,'number',p.number)
   order by coalesce(previous.ordinal,1000+p.number),p.number),'[]'::jsonb)
  from cd_private.participants p
  left join lateral (
   select item.ordinal from cd_private.previews v,
   jsonb_array_elements(v.entries) with ordinality as item(entry,ordinal)
   where v.event_id=eid and item.entry->>'id'=p.id::text
  ) previous on true
  where p.event_id=eid and not p.excluded
 ),'shuffleId',(select id from cd_private.previews where event_id=eid))
 from public.cd_events e where e.id=eid;
$$;
create or replace function public.cd_shuffle(eid uuid, request_key uuid, map_index integer)
returns uuid language plpgsql security definer set search_path='' as $$
declare roster jsonb; mixed jsonb; previous cd_private.previews; preview_id uuid;
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 if request_key is null or map_index is null or map_index not between 0 and 3 then raise exception 'INVALID_SHUFFLE'; end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'number',number) order by number),'[]'::jsonb)
 into roster from cd_private.participants where event_id=eid and not excluded;
 if jsonb_array_length(roster)=0 then raise exception 'INVALID_COUNT'; end if;
 select * into previous from cd_private.previews where event_id=eid;
 if previous.request_id=request_key then
  if previous.map_index is distinct from map_index or previous.roster is distinct from roster then raise exception 'REQUEST_CONFLICT'; end if;
  update public.cd_events set lobby_map=map_index where id=eid;
  return previous.id;
 end if;
 select jsonb_agg(item order by random()) into mixed from jsonb_array_elements(roster) as items(item);
 preview_id:=gen_random_uuid();
 insert into cd_private.previews values(eid,preview_id,request_key,map_index,roster,mixed)
 on conflict(event_id) do update set id=excluded.id,request_id=excluded.request_id,map_index=excluded.map_index,roster=excluded.roster,entries=excluded.entries;
 update public.cd_events set lobby_map=map_index where id=eid;
 perform cd_private.touch(eid,'shuffle',jsonb_build_object('preview',preview_id)); return preview_id;
end $$;
create or replace function public.cd_prepare(eid uuid, request_key uuid, draw_mode text, winner_count integer, map_index integer, exclude_winners boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare r cd_private.rounds; entries jsonb; next_number integer; total integer; preview cd_private.previews;
begin
 perform cd_private.owner(eid); perform 1 from public.cd_events where id=eid for update;
 select * into r from cd_private.rounds where event_id=eid and request_id=request_key;
 if r.id is not null then
  if r.mode is distinct from draw_mode or r.winner_count is distinct from winner_count or r.map_index is distinct from map_index or r.exclude_winners is distinct from exclude_winners then raise exception 'REQUEST_CONFLICT'; end if;
  return r.id;
 end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then raise exception 'ROUND_ACTIVE'; end if;
 if not exists(select 1 from cd_private.displays where event_id=eid and seen_at>clock_timestamp()-interval '15 seconds') then raise exception 'DISPLAY_OFFLINE'; end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'number',number) order by number),'[]'::jsonb), count(*) into entries,total from cd_private.participants where event_id=eid and not excluded;
 select * into preview from cd_private.previews where event_id=eid;
 if preview.event_id is not null then
  if preview.map_index is distinct from map_index or preview.roster is distinct from entries then raise exception 'SHUFFLE_STALE'; end if;
  entries:=preview.entries;
 else
  select jsonb_agg(item order by random()) into entries from jsonb_array_elements(entries) as items(item);
 end if;
 if total=0 or winner_count is null or winner_count<1 or winner_count>total then raise exception 'INVALID_COUNT'; end if;
 select coalesce(max(number),0)+1 into next_number from cd_private.rounds where event_id=eid;
 insert into cd_private.rounds(event_id,number,request_id,mode,winner_count,map_index,exclude_winners,entries)
 values(eid,next_number,request_key,draw_mode,winner_count,map_index,exclude_winners,entries) returning * into r;
 delete from cd_private.previews where event_id=eid;
 update public.cd_events set lobby_map=map_index where id=eid;
 perform cd_private.touch(eid,'prepare',jsonb_build_object('round',r.id)); return r.id;
end $$;
create or replace function public.cd_display_snapshot(eid uuid) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 perform cd_private.display(eid);
 return jsonb_build_object('event',(select to_jsonb(e)-'owner_id' from public.cd_events e where id=eid),
 'lobby',cd_private.lobby_json(eid),
 'joinCode',(select join_code from cd_private.secrets where event_id=eid),
 'preview',cd_private.preview_json(eid),
 'round',(select cd_private.round_json(r) from cd_private.rounds r where event_id=eid order by number desc limit 1));
end $$;

revoke all on function cd_private.lobby_json(uuid) from public,anon,authenticated;
revoke all on function public.cd_set_map(uuid,integer) from public,anon,authenticated;
grant execute on function public.cd_set_map(uuid,integer) to authenticated;
notify pgrst, 'reload schema';
