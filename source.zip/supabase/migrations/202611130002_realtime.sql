-- Supabase-specific publication setup, separate from portable Postgres tests.
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='cd_events') then
  alter publication supabase_realtime add table public.cd_events;
 end if;
end $$;
