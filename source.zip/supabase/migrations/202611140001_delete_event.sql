-- Existing events are untouched. Only an explicit, owner-authorized RPC deletes one.
create or replace function public.cd_delete_event(eid uuid, confirm_title text)
returns void language plpgsql security definer set search_path='' as $$
declare current_title text;
begin
 perform cd_private.owner(eid);
 select title into current_title from public.cd_events where id=eid for update;
 if current_title is null then raise exception 'EVENT_NOT_FOUND'; end if;
 if confirm_title is distinct from current_title then raise exception 'CONFIRM_TITLE_MISMATCH'; end if;
 if exists(select 1 from cd_private.rounds where event_id=eid and status in ('prepared','running')) then
  raise exception 'ROUND_ACTIVE';
 end if;
 -- Foreign keys cascade to the event's roster, results, pairing and join codes.
 delete from public.cd_events where id=eid;
end $$;
revoke all on function public.cd_delete_event(uuid,text) from public,anon,authenticated;
grant execute on function public.cd_delete_event(uuid,text) to authenticated;
notify pgrst, 'reload schema';
