import {initialZoom} from './data/constants';
import type {StageDef} from './data/maps';
export type WaitingView='map'|'marbles';
/** Ignore the offscreen spawn chute extending to y=-300 when framing a stage. */
export function waitingFrame(stage:StageDef,count:number,view:WaitingView,width:number,height:number){
 const rows=Math.ceil(count/10),delta=-Math.max(0,rows-5);
 if(view==='marbles'&&count>0){
  const cols=Math.min(count,10),spanX=Math.max((cols-1)*.6,1)+6,spanY=Math.max(rows-1,1)+6;
  return {center:{x:10.25+(cols-1)*.3,y:(1+rows)/2+delta},zoom:Math.min(3,width/initialZoom/spanX,height/initialZoom/spanY)*.9};
 }
 const top=Math.min(0,1+delta)-3;
 let left=8,right=18,bottom=view==='map'?stage.goalY+4:Math.min(stage.goalY,24);
 for(const entity of stage.entities||[]){
  const {position:p,shape:s}=entity;
  if(view==='marbles'&&p.y>bottom)continue;
  if(s.type==='polyline'){
   const angle=s.rotation||0,c=Math.cos(angle),sin=Math.sin(angle);
   for(const [x,y] of s.points){const xx=p.x+x*c-y*sin,yy=p.y+x*sin+y*c;
    if(yy>=0&&yy<=bottom){left=Math.min(left,xx);right=Math.max(right,xx);}
   }
  }else{
   const radius=s.type==='circle'?s.radius:Math.hypot(s.width,s.height)/2;
   if(p.y+radius>=0&&p.y-radius<=bottom){left=Math.min(left,p.x-radius);right=Math.max(right,p.x+radius);}
  }
 }
 const spanX=right-left+8,spanY=bottom-top+4;
 return {center:{x:(left+right)/2,y:(top+bottom)/2},zoom:Math.min(width/initialZoom/spanX,height/initialZoom/spanY)*.84};
}
