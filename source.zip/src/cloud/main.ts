import type {SupabaseClient} from '@supabase/supabase-js';
import {connect,message,errorText} from './client';
export function startPage(kind:string,init:(client:SupabaseClient|null)=>Promise<void>){
 if(process.env.CD_TEST_MODE==='1'){
  const note=document.createElement('div');note.className='test-banner';note.textContent='로컬 연결 검증용 · 실제 참가 접수가 아닙니다';document.body.prepend(note);
 }
 void Promise.resolve().then(()=>init(connect(kind))).catch(e=>message(errorText(e)));
}
