import {validateName} from '../event/round';
/** Spaces belong to the name; rows, Excel cells and commas separate people. */
export function parseParticipantNames(text:string):string[]{
 const parts=text.split(/[\r\n,\t]+/).filter(name=>name.trim());
 if(parts.length>300)throw Error('한 번에 최대 300명까지 추가할 수 있습니다.');
 return parts.map((name,index)=>{
  try{return validateName(name);}catch(e){throw Error(`${index+1}번째 이름: ${e instanceof Error?e.message:'이름을 확인해 주세요.'}`);}
 });
}
