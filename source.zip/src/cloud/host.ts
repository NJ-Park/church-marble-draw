import type {SupabaseClient} from '@supabase/supabase-js';
import QRCode from 'qrcode';
import {stages} from '../data/maps';
import {validateName} from '../event/round';
import {publicLink,safeCsv,winnerLabel,type HostSnapshot} from './contracts';
import {$,value,message,rpc,watch,errorText} from './client';
const statusText={prepared:'명단 확정 · 방송 화면 시작 대기',running:'추첨 진행 중 · 명단 변경 잠김',completed:'결과 저장 완료',cancelled:'회차 취소됨',interrupted:'연결이 중단된 회차 · 자동 재추첨하지 않습니다'};
export async function hostPage(client:SupabaseClient|null){
 const previewLink=document.querySelector<HTMLAnchorElement>('#setup a');if(previewLink)previewLink.search='?preview=1';
 if(!client){$('setup').hidden=false;$('login').querySelectorAll<HTMLInputElement|HTMLButtonElement>('input,button').forEach(el=>el.disabled=true);return;}
 const db=client;
 let eid='',snapshot:HostSnapshot|null=null,stop=()=>{},loading=false,again=false,mutation=false,online=false;
 let renderedQr='',joinHref='',displayHref='';
 const base=process.env.CD_PUBLIC_SITE_URL||new URL('./',location.href).href;
 stages.forEach((m,i)=>($('map') as HTMLSelectElement).add(new Option(m.title,String(i))));
 const qrDialog=$('qr-dialog') as HTMLDialogElement,deleteDialog=$('delete-dialog') as HTMLDialogElement;
 let deleteTarget:{id:string;title:string}|null=null;
 const active=()=>snapshot?.rounds.find(r=>['prepared','running'].includes(r.status));
 async function perform(fn:()=>Promise<void>){
  if(mutation)return;mutation=true;render();
  try{await fn();message('');}catch(e){message(errorText(e));}
  finally{mutation=false;await refresh();render();}
 }
 function render(){
  if(!snapshot)return;const s=snapshot,busy=!!active();
  ($('delete-event') as HTMLButtonElement).disabled=busy||mutation||!online;
  $('qr-title').textContent=s.event.title;$('qr-large-status').textContent=s.event.registration_open?'참가 접수 중':'참가 접수가 마감되었습니다.';
  $('current-title').textContent=s.event.title;$('total').textContent=String(s.participants.length);
  $('eligible').textContent=String(s.participants.filter(p=>!p.excluded).length);$('excluded').textContent=String(s.participants.filter(p=>p.excluded).length);
  $('display-state').textContent=s.displayReady?'연결됨':'대기';$('registration-status').textContent=s.event.registration_open?'참가 접수 중':'참가 접수 마감';
  $('registration').textContent=s.event.registration_open?'접수 마감':'접수 다시 열기';
  for(const id of ['map','mode','count','exclude','import','pair'])($(id) as HTMLInputElement).disabled=busy||mutation||!online;
  ($('events') as HTMLSelectElement).disabled=mutation;
  ($('shuffle') as HTMLButtonElement).disabled=busy||mutation||!online||!s.participants.some(p=>!p.excluded);
  $('shuffle-status').textContent=s.preview?(s.preview.valid&&s.preview.map===Number(value('map'))?'이름표를 섞었습니다. 방송 화면에서 확인한 배치로 시작합니다.':'명단 또는 맵이 바뀌었습니다. 다시 섞어 주세요.'):'시작 전에 방송 화면에서 이름 배치를 미리 볼 수 있습니다.';
  ($('start') as HTMLButtonElement).disabled=busy||mutation||!online||!s.displayReady||!s.participants.some(p=>!p.excluded);
  ($('cancel') as HTMLButtonElement).disabled=(!busy&&s.rounds[0]?.status!=='interrupted')||mutation||!online;
  ($('registration') as HTMLButtonElement).disabled=mutation||!online;
  $('round-status').textContent=s.rounds[0]?`${s.rounds[0].number}회 · ${statusText[s.rounds[0].status]}`:'방송 화면을 연결하고 첫 회차를 준비해 주세요.';
  const query=value('search').trim();$('roster').replaceChildren();
  for(const p of s.participants){
   if(query&&!p.name.includes(query)&&!String(p.number).includes(query))continue;
   const tr=document.createElement('tr');for(const text of [String(p.number).padStart(3,'0'),p.name]){const td=document.createElement('td');td.textContent=text;tr.append(td);}
   const td=document.createElement('td'),b=document.createElement('button');b.className='secondary';b.textContent=p.excluded?'제외됨 · 복귀':'참가 · 제외';b.disabled=busy||mutation||!online;
   b.onclick=()=>void perform(async()=>{await rpc(db,'cd_exclude',{eid,participant_id:p.id,is_excluded:!p.excluded});});td.append(b);tr.append(td);$('roster').append(tr);
  }
  $('history').replaceChildren();
  const completed=s.rounds.filter(r=>r.status==='completed');
  if(!completed.length)$('history').textContent='완료된 회차가 없습니다.';
  completed.forEach(r=>{const p=document.createElement('p');p.textContent=`${r.number}회 · ${r.mode==='first'?'선착순':'최후 생존'} · ${winnerLabel(r)}`;$('history').append(p);});
  ($('export') as HTMLButtonElement).disabled=!completed.length;
  joinHref=publicLink(base,'join.html',{}, {code:s.joinCode});($('join-link') as HTMLAnchorElement).href=joinHref;
  $('qr-warning').textContent=new URL(joinHref).protocol!=='https:'?'이 주소는 공개 HTTPS 접수 주소가 아닙니다. 휴대폰 현장 접수 전에 배포 주소를 설정해 주세요.':'';
  if(renderedQr!==joinHref){const requestedHref=joinHref;renderedQr=requestedHref;void QRCode.toDataURL(requestedHref,{width:1200,margin:4,errorCorrectionLevel:'M'}).then(url=>{if(requestedHref===renderedQr){($('qr') as HTMLImageElement).src=url;($('qr-large') as HTMLImageElement).src=url;}}).catch(e=>message(errorText(e)));}
 }
 async function refresh(){
  if(!eid)return;if(loading){again=true;return;}loading=true;
  const selected=eid;
  try{const s=await rpc<HostSnapshot>(db,'cd_host_snapshot',{eid:selected});if(eid===selected){snapshot=s;online=true;const pendingKey=`cd-start-${selected}`,pending=JSON.parse(sessionStorage.getItem(pendingKey)||'null');if(pending&&s.rounds.some(r=>r.requestId===pending.id))sessionStorage.removeItem(pendingKey);$('event-panel').hidden=false;render();}}
  catch(e){if(eid===selected){online=false;render();message(errorText(e));}}finally{loading=false;if(again){again=false;void refresh();}}
 }
 async function selectEvent(id:string){
  qrDialog.close();deleteDialog.close();deleteTarget=null;
  stop();eid=id;snapshot=null;online=false;renderedQr='';$('display-link').hidden=true;$('copy-display').hidden=true;$('pair-info').textContent='';
  $('event-panel').hidden=true;if(!eid)return;
  await refresh();stop=watch(db,eid,()=>void refresh(),text=>{$('connection').textContent=text;});
 }
 async function loadEvents(preferred?:string){
  const {data,error}=await db.from('cd_events').select('id,title').order('created_at',{ascending:false});if(error)throw error;
  const select=$('events') as HTMLSelectElement;select.replaceChildren();for(const e of data||[])select.add(new Option(e.title,e.id));
  const id=preferred||(data?.[0]?.id??'');select.value=id;await selectEvent(id);
 }
 async function signedIn(){
  const {data,error}=await db.auth.getSession();if(error)throw error;
  const valid=!!data.session&&!data.session.user.is_anonymous;
  $('login').hidden=valid;$('workspace').hidden=!valid;
  if(valid)await loadEvents();
 }
 $('login').onsubmit=async e=>{e.preventDefault();const button=$('login').querySelector('button')!;button.disabled=true;try{
  const {error}=await db.auth.signInWithPassword({email:value('email').trim(),password:value('password')});if(error)throw error;
  ($('password') as HTMLInputElement).value='';message('');await signedIn();
 }catch(e){message(errorText(e));}finally{button.disabled=false;}};
 $('logout').onclick=()=>void perform(async()=>{if(active())throw Error('진행 중 회차를 마무리하거나 취소한 후 로그아웃해 주세요.');stop();await db.auth.signOut();location.reload();});
 $('show-qr').onclick=()=>{if(snapshot)qrDialog.showModal();};
 $('close-qr').onclick=()=>qrDialog.close();
 qrDialog.addEventListener('close',()=>{if(document.fullscreenElement===qrDialog)void document.exitFullscreen().catch(()=>{});});
 $('qr-fullscreen').onclick=()=>{if(qrDialog.requestFullscreen)void qrDialog.requestFullscreen().catch(()=>{$('qr-large-status').textContent='이 브라우저에서는 현재 확대 화면을 이용해 주세요.';});};
 $('delete-event').onclick=()=>{
  if(!snapshot||active()||mutation||!online)return;
  deleteTarget={id:eid,title:snapshot.event.title};$('delete-event-title').textContent=deleteTarget.title;
  ($('delete-confirm') as HTMLInputElement).value='';$('delete-error').textContent='';($('delete-submit') as HTMLButtonElement).disabled=true;
  deleteDialog.showModal();$('delete-confirm').focus();
 };
 $('delete-confirm').oninput=()=>{($('delete-submit') as HTMLButtonElement).disabled=mutation||!deleteTarget||value('delete-confirm')!==deleteTarget.title;};
 $('delete-cancel').onclick=()=>{if(!mutation)deleteDialog.close();};
 deleteDialog.addEventListener('cancel',e=>{if(mutation)e.preventDefault();});
 $('delete-form').onsubmit=async e=>{
  e.preventDefault();const target=deleteTarget;
  if(mutation||!target||target.id!==eid||value('delete-confirm')!==target.title)return;
  mutation=true;render();($('delete-submit') as HTMLButtonElement).disabled=true;($('delete-cancel') as HTMLButtonElement).disabled=true;
  try{
   await rpc(db,'cd_delete_event',{eid:target.id,confirm_title:value('delete-confirm')});
   deleteDialog.close();await selectEvent('');await loadEvents();message('행사를 삭제했습니다.');
  }catch(e){$('delete-error').textContent=errorText(e);}
  finally{mutation=false;($('delete-cancel') as HTMLButtonElement).disabled=false;($('delete-submit') as HTMLButtonElement).disabled=!deleteTarget||value('delete-confirm')!==deleteTarget.title;render();}
 };
 $('events').onchange=()=>void selectEvent(value('events')).catch(e=>message(errorText(e)));
 $('create').onsubmit=e=>{e.preventDefault();void perform(async()=>{
  const id=await rpc<string>(db,'cd_create_event',{event_title:value('event-title').trim(),max_people:300});($('event-title') as HTMLInputElement).value='';await loadEvents(id);
 });};
 $('search').oninput=render;
 $('map').onchange=render;
 $('shuffle').onclick=()=>void perform(async()=>{
  const key=`cd-shuffle-${eid}`,payload={eid,map_index:Number(value('map'))},saved=JSON.parse(sessionStorage.getItem(key)||'null');
  if(saved&&JSON.stringify(saved.payload)!==JSON.stringify(payload))throw Error('이전 이름표 섞기 요청을 같은 맵으로 다시 시도해 주세요.');
  const request_key=saved?.id||crypto.randomUUID();sessionStorage.setItem(key,JSON.stringify({id:request_key,payload}));
  try{await rpc(db,'cd_shuffle',{...payload,request_key});sessionStorage.removeItem(key);}
  catch(e){if(e&&typeof e==='object'&&'code'in e&&e.code)sessionStorage.removeItem(key);throw e;}
 });
 $('registration').onclick=()=>void perform(async()=>{await rpc(db,'cd_set_registration',{eid,is_open:!snapshot!.event.registration_open});});
 $('import').onclick=()=>void perform(async()=>{
  const names=value('names').split(/\r?\n/).filter(x=>x.trim()).map(validateName);if(!names.length)throw Error('추가할 이름을 입력해 주세요.');
  const key=`cd-import-${eid}`,payload=JSON.stringify(names),saved=JSON.parse(sessionStorage.getItem(key)||'null');
  if(saved&&saved.payload!==payload)throw Error('이전 명단 추가 요청을 같은 내용으로 재시도해 주세요.');
  const request_key=saved?.id||crypto.randomUUID();sessionStorage.setItem(key,JSON.stringify({id:request_key,payload}));
  try{await rpc(db,'cd_import',{eid,request_key,names});sessionStorage.removeItem(key);($('names') as HTMLInputElement).value='';}
  catch(e){if(e&&typeof e==='object'&&'code'in e&&e.code)sessionStorage.removeItem(key);throw e;}
 });
 $('pair').onclick=()=>void perform(async()=>{
  const pair=await rpc<string>(db,'cd_rotate_display',{eid});displayHref=publicLink(base,'display.html',{event:eid},{pair});
  ($('display-link') as HTMLAnchorElement).href=displayHref;$('display-link').hidden=false;$('copy-display').hidden=false;$('pair-info').textContent='10분 동안 유효하며 한 번 연결하면 만료됩니다.';
 });
 $('copy-link').onclick=()=>void navigator.clipboard.writeText(joinHref).then(()=>message('참가 링크를 복사했습니다.')).catch(()=>message('접수 화면 링크를 길게 눌러 복사해 주세요.'));
 $('copy-display').onclick=()=>void navigator.clipboard.writeText(displayHref).then(()=>message('방송 연결 링크를 복사했습니다.')).catch(()=>message('방송 연결 링크를 직접 복사해 주세요.'));
 $('start').onclick=()=>void perform(async()=>{
  const payload={eid,draw_mode:value('mode'),winner_count:Number(value('count')),map_index:Number(value('map')),exclude_winners:($('exclude') as HTMLInputElement).checked};
  const key=`cd-start-${eid}`,saved=JSON.parse(sessionStorage.getItem(key)||'null');
  if(saved&&JSON.stringify(saved.payload)!==JSON.stringify(payload))throw Error('이전 시작 요청을 같은 설정으로 재시도해 주세요.');
  const request_key=saved?.id||crypto.randomUUID();sessionStorage.setItem(key,JSON.stringify({id:request_key,payload}));
  try{await rpc(db,'cd_prepare',{...payload,request_key});sessionStorage.removeItem(key);}catch(e){if(e&&typeof e==='object'&&'code'in e&&e.code)sessionStorage.removeItem(key);throw e;}
 });
 $('cancel').onclick=()=>void perform(async()=>{const round=active()||snapshot?.rounds[0];if(round)await rpc(db,'cd_cancel',{eid,rid:round.id});sessionStorage.removeItem(`cd-start-${eid}`);});
 $('export').onclick=()=>{
  if(!snapshot)return;const rows=[['회차','방식','이름','참가번호','저장시각']];
  snapshot.rounds.filter(r=>r.status==='completed').forEach(r=>r.winnerIds?.forEach(id=>{const p=r.entries.find(p=>p.id===id)!;rows.push([String(r.number),r.mode==='first'?'선착순':'최후 생존',p.name,String(p.number),r.completedAt||'']);}));
  const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(row=>row.map(safeCsv).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='church-draw-results.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 };
 await signedIn();
}
