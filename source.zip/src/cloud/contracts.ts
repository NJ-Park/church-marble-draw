export const ENGINE_VERSION='e9a9d22-event-v2';
export type Entry={id:string;name:string;number:number};
export type Participant=Entry&{excluded:boolean};
export type Round={id:string;requestId:string;number:number;mode:'first'|'last';count:number;map:number;excludeWinners:boolean;status:'prepared'|'running'|'completed'|'cancelled'|'interrupted';entries:Entry[];winnerIds:string[]|null;engineVersion:string;createdAt:string;completedAt:string|null};
export type EventInfo={id:string;title:string;capacity:number;registration_open:boolean;revision:number};
export type HostSnapshot={event:EventInfo;joinCode:string;displayReady:boolean;participants:Participant[];rounds:Round[]};
export type DisplaySnapshot={event:EventInfo;round:Round|null};
export type Receipt={id:string;name:string;number:number;existing:boolean};
export function parseConfig(url:string,key:string,localTest=false){
 if(!url&&!key)return null;
 if(!url||!key)throw Error('Supabase URL과 공개키를 모두 설정해 주세요.');
 const parsed=new URL(url);
 if((parsed.protocol!=='https:'&&!(localTest&&parsed.protocol==='http:'&&['localhost','127.0.0.1'].includes(parsed.hostname)))||parsed.username||parsed.password)throw Error('Supabase URL은 HTTPS 주소여야 합니다.');
 if(key.startsWith('sb_secret_'))throw Error('비밀키는 브라우저에 넣을 수 없습니다. publishable key를 사용하세요.');
 if(key.startsWith('eyJ')){
  let role:string;try{role=JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role;}catch{throw Error('공개키 형식이 올바르지 않습니다.');}
  if(role!=='anon')throw Error('anon 공개키만 사용할 수 있습니다.');
 }else if(!key.startsWith('sb_publishable_'))throw Error('publishable key 또는 anon key를 사용해 주세요.');
 return {url:parsed.origin,key};
}
export function publicLink(base:string,page:string,params:Record<string,string>,fragment:Record<string,string>={}){
 const url=new URL(page,base);if(!['http:','https:'].includes(url.protocol))throw Error('올바른 사이트 주소가 필요합니다.');
 url.search=new URLSearchParams(params).toString();url.hash=new URLSearchParams(fragment).toString();return url.href;
}
export function roundRange(r:Round){
 if(r.entries.length<r.count||r.count<1||!Number.isInteger(r.count))throw Error('회차 명단과 당첨 인원이 맞지 않습니다.');
 return r.mode==='first'?{start:0,end:r.count-1}:{start:r.entries.length-r.count,end:r.entries.length-1};
}
export function winnerLabel(r:Round){return (r.winnerIds||[]).map(id=>{const p=r.entries.find(x=>x.id===id);return p?`${p.name} #${p.number}`:'확인되지 않은 참가자';}).join(', ');}
export function safeCsv(value:unknown){let s=String(value??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
