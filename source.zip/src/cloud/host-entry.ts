import {startPage} from './main';
import {hostPage} from './host';
startPage('host',hostPage);
