import {startPage} from './main';
import {joinPage} from './join';
startPage('join',joinPage);
