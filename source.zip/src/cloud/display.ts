import QRCode from 'qrcode';
import type {SupabaseClient} from '@supabase/supabase-js';
import type {WaitingView} from '../waitingView';
import options from '../options';
import {EventEngine} from '../event/engine';
import {ENGINE_VERSION,roundRange,winnerLabel,publicLink,type DisplaySnapshot,type Round} from './contracts';
import {$,message,anonymous,rpc,watch,errorText} from './client';
type Pending={eid:string;rid:string;sid:string;token:string;winners:string[]};
export async function displayPage(client:SupabaseClient|null){
 if(!client){$('setup').hidden=false;message('Supabase 연결 전입니다.');return;}
 const db=client,eid=new URLSearchParams(location.search).get('event');
 if(!eid){$('setup').hidden=false;message('진행자가 발급한 방송 연결 링크가 필요합니다.');return;}
 if(!navigator.locks)throw Error('이 브라우저는 방송 실행 잠금을 지원하지 않습니다. 최신 Chrome을 사용해 주세요.');
 const lockName=`cloud-display-${eid}`;
 await navigator.locks.request(lockName,{ifAvailable:true},async lock=>{
  if(!lock){message('이 브라우저에 이미 같은 행사 방송 화면이 열려 있습니다.');return;}
  await anonymous(db);
  const pair=new URLSearchParams(location.hash.slice(1)).get('pair');
  if(pair){await rpc(db,'cd_pair_display',{eid,code:pair});history.replaceState(null,'',location.pathname+location.search);}
  const pendingKey=`cd-result-${eid}`;
  let pending=JSON.parse(sessionStorage.getItem(pendingKey)||'null') as Pending|null;
  // A fresh page gets a fresh execution identity; it must never replay a running round.
  const sid=pending?.sid||crypto.randomUUID();
  const game=new EventEngine();options.useSkills=false;game.setAutoRecording(false);
  await new Promise<void>((resolve,reject)=>{const began=Date.now(),t=setInterval(()=>{
   if(game.isReady){clearInterval(t);resolve();}else if(Date.now()-began>20000){clearInterval(t);reject(Error('엔진을 불러오지 못했습니다. 연결을 확인해 주세요.'));}
  },50);});
  let active:{round:Round;token:string}|null=null,refreshing=false,again=false,saving=false,stopped=false;
  let lastBeat=0,lastLayout='',heldResult='',heldLayout='';
  let waitingView:WaitingView='map',latest:DisplaySnapshot|null=null,qrHref='',registrationShown:boolean|null=null;
  const publicBase=process.env.CD_PUBLIC_SITE_URL||new URL('./',location.href).href;
  function syncRegistration(s:DisplaySnapshot){
   const show=s.event.registration_open&&s.event.qr_enabled!==false&&!!s.joinCode;
   if(registrationShown!==show){
    if(registrationShown!==null&&(!s.round||!['prepared','running'].includes(s.round.status))){active=null;lastLayout='';heldResult='';}
    registrationShown=show;waitingView=show?'marbles':'map';
    $('view-map').setAttribute('aria-pressed',String(waitingView==='map'));
    $('view-marbles').setAttribute('aria-pressed',String(waitingView==='marbles'));
   }
   $('registration-panel').hidden=!show;document.body.classList.toggle('registration-open',show);
   if(!show)return;
   const href=publicLink(publicBase,'join.html',{}, {code:s.joinCode!});
   if(href===qrHref)return;qrHref=href;
   $('display-qr-note').textContent='QR 준비 중';
   void QRCode.toDataURL(href,{width:1000,margin:4,errorCorrectionLevel:'M'}).then(url=>{
    if(qrHref!==href)return;($('display-qr') as HTMLImageElement).src=url;
    $('display-qr-note').textContent='등록하면 오른쪽에 구슬이 나타납니다';
   }).catch(()=>{$('display-qr-note').textContent='QR을 불러오지 못했습니다. 방송 화면을 새로 열어 주세요.';qrHref='';});
  }
  const canvas=document.querySelector('canvas')!;
  const resizeView=new ResizeObserver(()=>{requestAnimationFrame(()=>{
   if(!active&&latest?.lobby&&(!latest.round||!['prepared','running'].includes(latest.round.status)))game.showWaitingView(waitingView);
  });});resizeView.observe(canvas);

  function layoutKey(s:DisplaySnapshot){return JSON.stringify(s.lobby||null);}
  function viewsEnabled(enabled:boolean){for(const id of ['view-map','view-marbles'])($(id) as HTMLButtonElement).disabled=!enabled;}
  function renderLobby(s:DisplaySnapshot,force=false){
   const lobby=s.lobby;
   if(!lobby){
    if(!lastLayout){game.setMap(s.event.lobby_map??0);game.showWaitingView('map');lastLayout='missing-lobby';}
    message('방송 동기화 설정이 필요합니다. 최신 Supabase 추가 SQL을 적용해 주세요.');return;
   }
   const key=layoutKey(s);
   if(force||lastLayout!==key){
    active=null;game.setMap(lobby.map);
    if(lobby.entries.length)game.setParticipants(lobby.entries.map(p=>({id:p.id,name:`${p.name} #${p.number}`})),true);
    else game.setMarbles([]);
    game.showWaitingView(waitingView);lastLayout=key;
   }
   viewsEnabled(true);
   document.querySelector('canvas')?.setAttribute('aria-label',`대기 화면 · 구슬 ${lobby.entries.length}개`);
   message(`${lobby.entries.length}명 · ${s.preview?.valid?'이름표 섞기 완료':'참가 대기 중'}`);
  }
  function chooseView(view:WaitingView){
   waitingView=view;
   $('view-map').setAttribute('aria-pressed',String(view==='map'));$('view-marbles').setAttribute('aria-pressed',String(view==='marbles'));
   if(latest&&(!latest.round||!['prepared','running'].includes(latest.round.status)))renderLobby(latest,true);
  }
  $('view-map').onclick=()=>chooseView('map');$('view-marbles').onclick=()=>chooseView('marbles');
  game.showWaitingView('map');

  async function saveResult(){
   if(!pending||saving||stopped)return;saving=true;
   try{
    message('추첨 완료 · 서버에 결과를 저장하고 있습니다.');
    await rpc(db,'cd_finish',{eid:pending.eid,rid:pending.rid,sid:pending.sid,token:pending.token,winners:pending.winners});
    sessionStorage.removeItem(pendingKey);pending=null;$('retry-result').hidden=true;message('결과 저장 완료');
   }catch(e){
    const terminal=String((e as {message?:string})?.message||e).includes('LEASE_EXPIRED_OR_CANCELLED');
    if(terminal){sessionStorage.setItem(`${pendingKey}-discarded`,JSON.stringify(pending));sessionStorage.removeItem(pendingKey);pending=null;$('retry-result').hidden=true;game.reset();active=null;message('취소·만료된 회차의 결과는 저장하지 않았습니다.');}
    else{message(`결과 저장 확인 필요 · ${errorText(e)}`);$('retry-result').hidden=false;}
   }
   finally{saving=false;}
  }
  $('retry-result').onclick=()=>void saveResult();
  async function refresh(){
   if(stopped)return;if(refreshing){again=true;return;}refreshing=true;
   try{
    const s=await rpc<DisplaySnapshot>(db,'cd_display_snapshot',{eid});latest=s;syncRegistration(s);
    const r=s.round;
    if(pending){
     if(r?.id===pending.rid&&['cancelled','interrupted'].includes(r.status)){
      sessionStorage.setItem(`${pendingKey}-discarded`,JSON.stringify(pending));sessionStorage.removeItem(pendingKey);pending=null;$('retry-result').hidden=true;game.reset();active=null;
     }
     await saveResult();if(pending)return;
    }
    if(!r||!['prepared','running'].includes(r.status)){
     // Keep the result popup until the waiting roster/map changes or a view button is used.
     if(r?.status==='completed'&&active?.round.id===r.id){
      if(heldResult!==r.id){heldResult=r.id;heldLayout=layoutKey(s);}
      if(heldLayout===layoutKey(s)){viewsEnabled(true);message(`${r.number}회 당첨 · ${winnerLabel(r)}`);return;}
     }
     renderLobby(s);return;
    }
    viewsEnabled(false);
    if(r.status==='running'){
     if(active?.round.id!==r.id){
      if(lastLayout!==`running-${r.id}`){game.setMap(r.map);game.setMarbles([]);game.showWaitingView('map');lastLayout=`running-${r.id}`;}
      message('진행 중인 회차입니다. 새로고침 후 재실행하지 않습니다. 진행자 화면에서 상태를 확인해 주세요.');
     }
     else if(Date.now()-lastBeat<12000)message(`${r.number}회 · ${r.entries.length}명 · ${r.mode==='first'?'선착순':'최후 생존'} ${r.count}명`);
     return;
    }
    if(active?.round.id===r.id)return;
    if(r.engineVersion!==ENGINE_VERSION)throw Error('ENGINE_VERSION_MISMATCH');
    const token=await rpc<string>(db,'cd_claim',{eid,rid:r.id,sid,version:ENGINE_VERSION});
    active={round:r,token};lastLayout='';heldResult='';
    game.setMap(r.map);game.setParticipants(r.entries.map(p=>({id:p.id,name:`${p.name} #${p.number}`})),true);
    const range=roundRange(r);game.setWinnerRange(range.start,range.end);game.start();
    message(`${r.number}회 · ${r.entries.length}명 · ${r.mode==='first'?'선착순':'최후 생존'} ${r.count}명`);
   }catch(e){message(errorText(e));}
   finally{refreshing=false;if(again){again=false;void refresh();}}
  }
  game.addEventListener('goal',event=>{
   if(!active||pending||stopped)return;
   pending={eid,rid:active.round.id,sid,token:active.token,winners:(event as CustomEvent).detail.participantIds};
   // Persist before sending: retries keep the same outcome, never run the engine again.
   try{sessionStorage.setItem(pendingKey,JSON.stringify(pending));}catch{message('결과 임시 보관에 실패했습니다. 이 창을 닫지 마세요.');}
   void saveResult();
  });
  let heartbeatBusy=false;
  async function heartbeat(){
   if(heartbeatBusy||stopped)return;heartbeatBusy=true;
   try{
    const valid=await rpc<boolean>(db,'cd_heartbeat',{eid,sid});lastBeat=Date.now();
    if(!valid&&active&&!pending){game.reset();active=null;message('방송 실행 권한이 만료되었습니다. 진행자가 새 회차를 준비해야 합니다.');}
   }catch(e){if(String((e as {message?:string})?.message||e).includes('DISPLAY_FORBIDDEN')){game.reset();active=null;}message(`방송 연결 확인 필요 · ${errorText(e)}`);}
   finally{heartbeatBusy=false;}
  }
  const stopWatch=watch(db,eid,()=>void refresh(),()=>{});
  const timer=setInterval(()=>void heartbeat(),5000);
  window.addEventListener('pagehide',()=>{stopped=true;clearInterval(timer);stopWatch();resizeView.disconnect();},{once:true});
  await heartbeat();await refresh();
  await new Promise(()=>{});
 });
}
