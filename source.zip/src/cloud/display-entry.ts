import {startPage} from './main';
import {displayPage} from './display';
startPage('display',displayPage);
