import type {SupabaseClient} from '@supabase/supabase-js';
import {validateName} from '../event/round';
import type {Receipt} from './contracts';
import {$,value,message,anonymous,rpc,errorText} from './client';
export async function joinPage(client:SupabaseClient|null){
 const preview=new URLSearchParams(location.search).has('preview');
 const code=new URLSearchParams(location.hash.slice(1)).get('code');
 const submit=$('join-submit') as HTMLButtonElement;
 let open=false;
 const receipt=(p:Receipt)=>{
  $('join-form').hidden=true;$('receipt').hidden=false;
  $('receipt-name').textContent=p.name;$('receipt-number').textContent=String(p.number).padStart(3,'0');
  message(preview?'미리보기입니다. 실제 접수는 이루어지지 않았습니다.':p.existing?'이미 등록된 참가 정보를 확인했습니다.':'접수가 완료되었습니다.');
 };
 if(preview){$('preview-note').hidden=false;open=true;$('join-title').textContent='함께하는 교회 행사';$('capacity').textContent='최대 300명 · 화면 미리보기';}
 else if(!client){$('setup').hidden=false;submit.disabled=true;return;}
 else if(!code){message('행사장의 QR 코드를 스캔해 주세요.');submit.disabled=true;return;}
 else{
  submit.disabled=true;
  try{
   const info=await rpc<{title:string;open:boolean;qrEnabled?:boolean;registered:number;capacity:number}>(client,'cd_event_info',{code});
   $('join-title').textContent=info.title;$('capacity').textContent=`${info.registered} / ${info.capacity}명 등록`;
   open=info.open; // Server accepts a previous registration retry even after closing/full.
   const saved=localStorage.getItem(`cd-receipt-${code}`);
   if(saved){const p=JSON.parse(saved) as Receipt;$('join-name').setAttribute('value',p.name);submit.textContent='내 참가 등록 확인';open=true;}
   if(!open)message(info.qrEnabled===false?'QR 참가는 사용하지 않는 행사입니다. 진행자에게 참가 등록을 요청해 주세요.':'참가 접수가 마감되었습니다.');
   submit.disabled=!open;
  }catch(e){message(errorText(e));return;}
 }
 $('join-form').onsubmit=async e=>{
  e.preventDefault();submit.disabled=true;
  try{
   const name=validateName(value('join-name'));
   if(!($('consent') as HTMLInputElement).checked)throw Error('표시 이름 사용에 동의해 주세요.');
   if(preview){receipt({id:'preview',name,number:12,existing:false});return;}
   if(!client||!code)throw Error('참가 링크를 확인해 주세요.');
   await anonymous(client);
   const p=await rpc<Receipt>(client,'cd_register',{code,display_name:name});
   localStorage.setItem(`cd-receipt-${code}`,JSON.stringify(p));receipt(p);
  }catch(e){message(errorText(e));}finally{submit.disabled=false;}
 };
}
