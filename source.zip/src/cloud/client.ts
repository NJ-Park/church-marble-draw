import {createClient, type SupabaseClient} from '@supabase/supabase-js';
import {parseConfig} from './contracts';
export function connect(kind:string):SupabaseClient|null{
 const config=parseConfig(process.env.CD_SUPABASE_URL||'',process.env.CD_SUPABASE_PUBLISHABLE_KEY||'',process.env.CD_TEST_MODE==='1');
 return config?createClient(config.url,config.key,{auth:{storageKey:`church-draw-auth-${kind}`,persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}}):null;
}
export async function rpc<T>(client:SupabaseClient,name:string,args:Record<string,unknown>={}):Promise<T>{
 const {data,error}=await client.rpc(name,args);if(error)throw error;return data as T;
}
export async function anonymous(client:SupabaseClient){
 const {data,error}=await client.auth.getSession();if(error)throw error;
 if(!data.session){const result=await client.auth.signInAnonymously();if(result.error)throw result.error;}
}
export function watch(client:SupabaseClient,eid:string,refresh:()=>void,status:(s:string)=>void){
 let timer:ReturnType<typeof setTimeout>|undefined;
 const schedule=()=>{if(timer)return;timer=setTimeout(()=>{timer=undefined;refresh();},150);};
 const channel=client.channel(`draw:${eid}:${crypto.randomUUID()}`).on('postgres_changes',{event:'UPDATE',schema:'public',table:'cd_events',filter:`id=eq.${eid}`},schedule).subscribe(s=>{
  status(s==='SUBSCRIBED'?'실시간 연결됨':'실시간 연결 복구 중 · 주기적으로 최신 상태를 확인합니다');schedule();
 });
 const poll=setInterval(schedule,5000);window.addEventListener('online',schedule);
 return ()=>{clearInterval(poll);clearTimeout(timer);window.removeEventListener('online',schedule);void client.removeChannel(channel);};
}
const messages:Record<string,string>={SHUFFLE_STALE:'명단 또는 맵이 바뀌었습니다. 이름표를 다시 섞은 후 시작해 주세요.',INVALID_SHUFFLE:'맵과 참가 명단을 확인해 주세요.',CONFIRM_TITLE_MISMATCH:'확인을 위해 행사 이름을 정확히 입력해 주세요.',FORBIDDEN:'진행자 권한이 없습니다.',DISPLAY_FORBIDDEN:'방송 연결이 해제됐습니다. 새 연결 링크가 필요합니다.',HOST_LOGIN_REQUIRED:'진행자 계정으로 로그인해 주세요.',EVENT_NOT_FOUND:'참가 링크를 확인해 주세요.',REGISTRATION_CLOSED:'참가 접수가 마감되었습니다.',CAPACITY_REACHED:'참가 정원에 도달했습니다.',INVALID_NAME:'이름은 제어문자 없이 1~30자로 입력해 주세요.',ROUND_ACTIVE:'추첨 중에는 이 설정을 변경할 수 없습니다.',INVALID_PAIR_CODE:'방송 연결 링크가 만료되었거나 이미 사용되었습니다.',DISPLAY_OFFLINE:'방송 화면을 연결한 뒤 다시 시도해 주세요.',INVALID_COUNT:'당첨 인원이 추첨 가능 인원을 넘지 않는지 확인해 주세요.',ROUND_ALREADY_CLAIMED:'이미 실행 중이거나 완료된 회차입니다. 자동으로 재추첨하지 않습니다.',ENGINE_VERSION_MISMATCH:'방송 화면을 최신 버전으로 다시 열어 주세요.',LEASE_EXPIRED_OR_CANCELLED:'연결이 오래 끊겼거나 회차가 취소되어 결과를 저장할 수 없습니다.',EXECUTION_FORBIDDEN:'이 방송 화면의 실행 권한이 일치하지 않습니다.',INVALID_WINNERS:'결과 검증에 실패했습니다. 진행자에게 알려 주세요.',RESULT_CONFLICT:'이미 저장된 결과와 다릅니다. 덮어쓰지 않았습니다.',REQUEST_CONFLICT:'이전 요청과 설정이 다릅니다. 현재 회차 상태를 확인해 주세요.'};
export function errorText(e:unknown){const text=e&&typeof e==='object'&&'message'in e?String(e.message):String(e);for(const [code,message]of Object.entries(messages))if(text.includes(code))return message;return text.includes('fetch')?'네트워크 연결을 확인하고 다시 시도해 주세요.':text;}
export const $=(id:string)=>document.getElementById(id)!;
export const value=(id:string)=>($(id) as HTMLInputElement).value;
export function message(text:string){$('message').textContent=text;}
export async function action(button:HTMLButtonElement,fn:()=>Promise<void>){button.disabled=true;try{await fn();}catch(e){message(errorText(e));}finally{button.disabled=false;}}
