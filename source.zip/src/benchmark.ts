import { Roulette } from './roulette';
const game = new Roulette();
game.setAutoRecording(false);
const $ = (id: string) => document.getElementById(id)!;
const input = (id: string) => $(id) as HTMLSelectElement;
for (const map of game.getMaps()) input('map').add(new Option(map.title, String(map.index)));
let start = 0, prev = 0, frames: number[] = [], hidden = false;
const records: unknown[] = [];
let active = false;
function stats() {
  const sorted = [...frames].sort((a,b) => a-b);
  const sum = frames.reduce((a,b) => a+b,0);
  return { frames: frames.length, fps: +(frames.length * 1000 / sum).toFixed(1),
    p95FrameMs: +(sorted[Math.floor(sorted.length * .95)] || 0).toFixed(1),
    over50ms: frames.filter(x => x > 50).length, hidden };
}
function tick(now: number) {
  if (active) {
    if (prev) frames.push(now-prev);
    prev=now;
    hidden ||= document.hidden;
    $('status').textContent = JSON.stringify({elapsedSeconds:+((now-start)/1000).toFixed(1),remaining:game.getCount(),...stats()});
  }
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);
const ready = setInterval(() => { if (game.isReady) {
  clearInterval(ready); ($('run') as HTMLButtonElement).disabled=false; $('status').textContent='준비 완료';
}},100);
$('run').onclick=()=>{
  game.setMap(Number(input('map').value));
  const n=Number(input('count').value);
  game.setMarbles(Array.from({length:n},(_,i)=>`참가자${String(i+1).padStart(3,'0')}`));
  game.setWinningRank(input('mode').value==='last'?n-1:0);
  frames=[];prev=0;hidden=document.hidden;start=performance.now();active=true;
  ($('run') as HTMLButtonElement).disabled=true;
  game.start();
};
game.addEventListener('goal',(e)=>{
  active=false;
  records.push({count:Number(input('count').value),map:game.getCurrentMap(),mode:input('mode').value,
    durationSeconds:+((performance.now()-start)/1000).toFixed(2),...stats(),result:(e as CustomEvent).detail,
    viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},userAgent:navigator.userAgent});
  $('results').textContent=JSON.stringify(records,null,2);
  ($('run') as HTMLButtonElement).disabled=false;
});
