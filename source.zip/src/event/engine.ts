import { KeywordService } from '../keywordService';
import { Roulette } from '../roulette';
import { RouletteRenderer } from '../rouletteRenderer';
// Event entrypoint does not use upstream advertising/keyword services.
class EventKeywords extends KeywordService { async init() {} }
class EventRenderer extends RouletteRenderer {
  protected createKeywordService() { return new EventKeywords(); }
}
export class EventEngine extends Roulette {
  protected createRenderer() { return new EventRenderer(); }
}
