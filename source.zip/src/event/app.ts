import { stages } from '../data/maps';
import options from '../options';
import { EventEngine } from './engine';
import { completeRound, prepareRound, validateName, type Participant, type Round } from './round';
type Status='idle'|'prepared'|'running'|'completed'|'cancelled'|'interrupted';
type Result={round:Round;ids:string[]};
type State={participants:Participant[];round:Round|null;status:Status;history:Result[]};
const KEY='church-draw-local-v1';
const channel=new BroadcastChannel(KEY);
const $=(id:string)=>document.getElementById(id)!;
const value=(id:string)=>($(id) as HTMLInputElement).value;
const read=():State=>JSON.parse(localStorage.getItem(KEY)||'{"participants":[],"round":null,"status":"idle","history":[]}');
const busy=(s:State)=>s.status==='prepared'||s.status==='running';
const screen=new URLSearchParams(location.search).has('screen');
let lastSeen=0;
async function update(fn:(s:State)=>State) {
  await navigator.locks.request(`${KEY}-state`,async()=>{
    const next=fn(read());localStorage.setItem(KEY,JSON.stringify(next));channel.postMessage({type:'changed',state:next});
  });
  refresh();
}
const statusText:Record<Status,string>={idle:'회차 준비',prepared:'방송 화면이 명단을 받는 중',running:'추첨 진행 중 · 명단이 잠겼습니다',completed:'당첨 기록 저장 완료',cancelled:'취소됨 · 당첨자 없음',interrupted:'방송이 중단되었습니다. 이 회차는 당첨 처리하지 않습니다.'};
function refresh() {
  if(screen) return;
  const s=read();
  $('total').textContent=String(s.participants.length);
  $('eligible').textContent=String(s.participants.filter(p=>!p.excluded).length);
  $('excluded').textContent=String(s.participants.filter(p=>p.excluded).length);
  $('connection').textContent=Date.now()-lastSeen<3500?'연결됨':'대기';
  for(const id of ['add','sample','map','mode','count','exclude']) ($(id) as HTMLInputElement).disabled=busy(s);
  ($('start') as HTMLButtonElement).disabled=busy(s)||Date.now()-lastSeen>=3500||!s.participants.some(p=>!p.excluded);
  ($('cancel') as HTMLButtonElement).disabled=!busy(s);
  $('status').textContent=statusText[s.status];
  const query=value('search').trim();
  $('roster').replaceChildren();
  s.participants.forEach((p,i)=>{
    if(query&&!p.name.includes(query)&&!String(i+1).includes(query))return;
    const tr=document.createElement('tr');
    for(const text of [String(i+1).padStart(3,'0'),p.name]){const td=document.createElement('td');td.textContent=text;tr.append(td);}
    const td=document.createElement('td'),button=document.createElement('button');
    button.textContent=p.excluded?'제외됨 · 복귀':'참가 · 제외';button.disabled=busy(s);button.className='secondary';
    button.onclick=()=>act(()=>update(current=>{
      if(busy(current))throw Error('진행 중에는 명단을 바꿀 수 없습니다.');
      return {...current,participants:current.participants.map(x=>x.id===p.id?{...x,excluded:!x.excluded}:x)};
    }));td.append(button);tr.append(td);$('roster').append(tr);
  });
  $('history').replaceChildren();
  if(!s.history.length)$('history').textContent='아직 완료된 회차가 없습니다.';
  s.history.slice().reverse().forEach((r,i)=>{
    const line=document.createElement('p');
    line.textContent=`${s.history.length-i}회 · ${r.round.mode==='first'?'선착순':'최후 생존'} · ${r.ids.map(id=>`${r.round.participants.find(p=>p.id===id)!.name} #${s.participants.findIndex(p=>p.id===id)+1}`).join(', ')}`;
    $('history').append(line);
  });
}
async function act(fn:()=>Promise<void>){try{await fn();}catch(e){$('status').textContent=e instanceof Error?e.message:String(e);}}
if(!screen){
  $('host').hidden=false;
  stages.forEach((m,i)=>($('map') as HTMLSelectElement).add(new Option(m.title,String(i))));
  $('search').oninput=refresh;
  $('add').onclick=()=>act(async()=>{
    const names=value('names').split(/\r?\n/).filter(x=>x.trim()).map(validateName);
    if(!names.length)throw Error('이름을 입력해 주세요.');
    await update(s=>{if(busy(s)||s.participants.length+names.length>300)throw Error('진행 중이거나 300명 제한을 넘습니다.');
      return {...s,participants:[...s.participants,...names.map(name=>({id:crypto.randomUUID(),name,excluded:false}))]};});
    ($('names') as HTMLTextAreaElement).value='';
  });
  $('sample').onclick=()=>act(()=>update(s=>{
    if(busy(s)||s.participants.length)throw Error('테스트 명단은 빈 명단에서만 생성합니다.');
    return {...s,participants:Array.from({length:300},(_,i)=>({id:crypto.randomUUID(),name:`참가자${String(i+1).padStart(3,'0')}`,excluded:false}))};
  }));
  $('start').onclick=()=>act(()=>update(s=>{
    if(busy(s)||Date.now()-lastSeen>3500)throw Error('방송 화면 연결과 회차 상태를 확인해 주세요.');
    const round=prepareRound(s.participants,{id:crypto.randomUUID(),mode:value('mode') as 'first'|'last',count:Number(value('count')),map:Number(value('map')),excludeWinners:($('exclude') as HTMLInputElement).checked});
    return {...s,round,status:'prepared'};
  }));
  $('cancel').onclick=()=>act(()=>update(s=>busy(s)?{...s,status:'cancelled'}:s));
  channel.onmessage=e=>{if(e.data.type==='sync-request'){channel.postMessage({type:'changed',state:read()});return;}if(e.data.type==='changed'&&e.data.state)localStorage.setItem(KEY,JSON.stringify(e.data.state));if(e.data.type==='heartbeat'){lastSeen=Date.now();$('connection').textContent='연결됨';($('start') as HTMLButtonElement).disabled=busy(read())||!read().participants.some(p=>!p.excluded);}else refresh();};
  setInterval(()=>{if(Date.now()-lastSeen>=3500){$('connection').textContent='대기';($('start') as HTMLButtonElement).disabled=true;}},1000);
  refresh();
}else{
  $('broadcast').hidden=false;
  navigator.locks.request(`${KEY}-renderer`,{ifAvailable:true},async lock=>{
    if(!lock){$('screen-status').textContent='다른 방송 화면이 이미 열려 있습니다.';return;}
    const game=new EventEngine();
    options.useSkills=false;game.setAutoRecording(false);
    await new Promise<void>(resolve=>{const timer=setInterval(()=>{if(game.isReady){clearInterval(timer);resolve();}},50);});
    // No replay after refresh: a new simulation could produce a different winner.
    if(read().status==='running')await update(s=>({...s,status:'interrupted'}));
    let activeId:string|null=null,processing=false;
    const handle=async()=>{
      if(processing)return;processing=true;
      try{
        const s=read();$('screen-status').textContent=statusText[s.status];
        if(s.status==='running'&&s.round?.id!==activeId){
          await update(current=>current.status==='running'?{...current,status:'interrupted'}:current);
          $('screen-status').textContent=statusText.interrupted;return;
        }
        if(s.status==='prepared'&&s.round){
          const round=s.round;
          let claimed=false;
          await update(current=>{if(current.status!=='prepared'||current.round?.id!==round.id)return current;claimed=true;return {...current,status:'running'};});
          if(!claimed)return;
          activeId=round.id;game.setMap(round.map);game.setParticipants(round.participants.map(p=>({...p,name:`${p.name} #${s.participants.findIndex(x=>x.id===p.id)+1}`})));
          game.setWinnerRange(round.winnerRange.start,round.winnerRange.end);game.start();
          $('screen-status').textContent=`${round.participants.length}명 · ${round.mode==='first'?'선착순':'최후 생존'} ${round.count}명`;
        }else if(!busy(s)&&s.status!=='completed'){activeId=null;game.reset();}
      }catch(e){$('screen-status').textContent=String(e);await update(s=>({...s,status:'interrupted'}));}
      finally{processing=false;}
    };
    game.addEventListener('goal',e=>{
      const roundId=activeId;const ids=(e as CustomEvent).detail.participantIds as string[];
      void update(s=>{
        if(s.status!=='running'||s.round?.id!==roundId)return s;
        const participants=completeRound(s.round,ids,s.participants);
        return {...s,participants,status:'completed',history:[...s.history,{round:s.round,ids}]};
      }).then(()=>{$('screen-status').textContent='추첨 완료 · 당첨 기록 저장됨';}).catch(e=>{$('screen-status').textContent=`결과 저장 실패: ${e}`;});
    });
    channel.onmessage=e=>{if(e.data.type==='changed'){if(e.data.state)localStorage.setItem(KEY,JSON.stringify(e.data.state));void handle();}};
    channel.postMessage({type:'sync-request'});
    setInterval(()=>channel.postMessage({type:'heartbeat'}),1000);
    await handle();
    await new Promise(()=>{});
  }).catch(e=>{$('screen-status').textContent=String(e);});
}
