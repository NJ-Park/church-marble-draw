export type Participant = { id: string; name: string; excluded: boolean };
export type DrawMode = 'first' | 'last';
export type Round = {
  id: string; mode: DrawMode; count: number; map: number;
  excludeWinners: boolean; participants: Participant[];
  winnerRange: { start: number; end: number };
};
export function validateName(value: string): string {
  const name = value.normalize('NFC').trim();
  if (!name || [...name].length > 30 || /[\p{Cc}\p{Cf}]/u.test(name))
    throw new Error('이름은 제어문자 없이 1~30자로 입력해 주세요.');
  return name;
}
export function prepareRound(participants: Participant[], settings: Omit<Round,'participants'|'winnerRange'>): Round {
  if (participants.length > 300 || new Set(participants.map(p=>p.id)).size !== participants.length || participants.some(p=>!p.id))
    throw new Error('참가자 ID 또는 최대 300명 제한을 확인해 주세요.');
  const eligible = participants.filter(p=>!p.excluded).map(p=>({...p,name:validateName(p.name)}));
  const {count,mode,map,id}=settings;
  if (!id || !['first','last'].includes(mode) || !Number.isInteger(map) || map<0 || map>3 ||
      !Number.isInteger(count) || count<1 || count>eligible.length)
    throw new Error('추첨 방식·맵·당첨 인원과 참가 인원을 확인해 주세요.');
  return {...settings,participants:eligible,winnerRange:mode==='first'?{start:0,end:count-1}:{start:eligible.length-count,end:eligible.length-1}};
}
export function completeRound(round: Round, winnerIds: string[], participants: Participant[]): Participant[] {
  if (winnerIds.length!==round.count || new Set(winnerIds).size!==winnerIds.length ||
      winnerIds.some(id=>!round.participants.some(p=>p.id===id))) throw new Error('유효하지 않은 추첨 결과입니다.');
  return participants.map(p=>({...p,excluded:p.excluded || (round.excludeWinners && winnerIds.includes(p.id))}));
}
