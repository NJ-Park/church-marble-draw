import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {parseConfig,publicLink,roundRange,safeCsv,type Round} from '../src/cloud/contracts';
const {validate}=createRequire(import.meta.url)('./cloud-config.cjs');
test('build refuses secrets before bundling and confines local QA configuration',()=>{
 assert.doesNotThrow(()=>validate({}));
 assert.throws(()=>validate({CD_SUPABASE_URL:'https://project.supabase.co',CD_SUPABASE_PUBLISHABLE_KEY:'sb_secret_not_public'}));
 assert.throws(()=>validate({CD_SUPABASE_URL:'https://project.supabase.co',CD_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_test',CD_TEST_MODE:'1'}));
 assert.doesNotThrow(()=>validate({CD_SUPABASE_URL:'http://127.0.0.1:1237',CD_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_test',CD_TEST_MODE:'1'}));
});
test('browser configuration refuses secret/service_role keys and unsafe URLs',()=>{
 assert.equal(parseConfig('',''),null);
 assert.throws(()=>parseConfig('https://project.supabase.co','sb_secret_no'));
 const key='eyJhbGciOiJIUzI1NiJ9.'+Buffer.from(JSON.stringify({role:'service_role'})).toString('base64url')+'.signature';
 assert.throws(()=>parseConfig('https://project.supabase.co',key));
 assert.throws(()=>parseConfig('http://not-secure.example','sb_publishable_test'));
 assert.equal(parseConfig('https://project.supabase.co','sb_publishable_test')?.url,'https://project.supabase.co');
});
test('QR and display link keep join/pair code in fragment, not request query',()=>{
 const url=new URL(publicLink('https://event.example/church/','join.html',{}, {code:'abc'}));
 assert.equal(url.pathname,'/church/join.html');assert.equal(url.search,'');assert.equal(url.hash,'#code=abc');
 const display=new URL(publicLink('https://event.example/','display.html',{event:'e'}, {pair:'secret'}));
 assert.equal(display.search,'?event=e');assert.equal(display.hash,'#pair=secret');
});
test('snapshot converts correctly to engine rank range',()=>{
 const r={entries:Array(299).fill(null),count:2,mode:'last'} as Round;
 assert.deepEqual(roundRange(r),{start:297,end:298});assert.deepEqual(roundRange({...r,mode:'first'}),{start:0,end:1});
 assert.throws(()=>roundRange({...r,count:300}));
});
test('CSV protects formula names and escapes quotes',()=>{
 assert.equal(safeCsv('=1+1'),'"\'=1+1"');assert.equal(safeCsv('김"민수'),'"김""민수"');assert.equal(safeCsv('김민수'),'"김민수"');
});
