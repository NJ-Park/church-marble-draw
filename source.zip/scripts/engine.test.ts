import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Roulette} from '../src/roulette';
import {parseName} from '../src/utils/utils';
function fixture() {
  const g=Object.create(Roulette.prototype) as any;
  g._isRunning=true;g._renderer={width:1280,height:720};g._particleManager={shot(){}};g._recorder={stop(){}};
  g.dispatchEvent=(e:CustomEvent)=>{g.emitted=e.detail;};
  return g;
}
const marble=(id:string)=>({name:'동명이인',participantId:id});
test('last survivor is selected without needing the final marble to cross',()=>{
  const g=fixture();g._winnerRange={start:299,end:299};g._winners=Array.from({length:299},(_,i)=>marble(String(i)));g._marbles=[marble('299')];
  g._checkFinish();assert.deepEqual(g.emitted.participantIds,['299']);assert.equal(g._isRunning,false);
});
test('multiple last winners wait for ordered ranks; no premature selection with two remaining',()=>{
  const g=fixture();g._winnerRange={start:297,end:299};g._winners=Array.from({length:298},(_,i)=>marble(String(i)));g._marbles=[marble('298'),marble('299')];
  g._checkFinish();assert.equal(g.emitted,undefined);
  g._winners.push(g._marbles.shift());g._checkFinish();assert.deepEqual(g.emitted.participantIds,['297','298','299']);
});
test('literal participant adapter keeps one marble per identity with duplicate and syntax names',()=>{
  const g=fixture();g.setMarbles=(names:string[])=>{g._marbles=names.flatMap(n=>{const p=parseName(n)!;return Array.from({length:p.count},()=>({name:p.name}));});};
  const p=[{id:'a',name:'김*300/9'},{id:'b',name:'김*300/9'}];g.setParticipants(p);
  assert.equal(g._marbles.length,2);assert.deepEqual(g._marbles.map((m:any)=>m.participantId),['a','b']);assert.equal(g._marbles[0].name,'김*300/9');
});
test('fixed preview layout and start keep the same slot-to-participant mapping',()=>{
 const g=fixture();g.reset=()=>{g._marbles=[];};
 g._camera={initializePosition(){}};g.physics={createMarble(id:number,x:number,y:number){positions.push({id,x,y});}};
 let positions:{id:number;x:number;y:number}[]=[];
 const entries=Array.from({length:300},(_,i)=>({id:`p${299-i}`,name:i<2?'동명이인':'김*300/9'}));
 g.setParticipants(entries,true);
 const first=g._marbles.map((m:any)=>({slot:m.id,id:m.participantId,name:m.name}));const firstPositions=positions;
 assert.deepEqual(first.map((m:any)=>m.id),entries.map(p=>p.id));assert.deepEqual(first.map((m:any)=>m.slot),Array.from({length:300},(_,i)=>i));
 positions=[];g.setParticipants(entries,true);
 assert.deepEqual(g._marbles.map((m:any)=>({slot:m.id,id:m.participantId,name:m.name})),first);assert.deepEqual(positions,firstPositions);
});
import {waitingFrame} from '../src/waitingView';
import {stages} from '../src/data/maps';
import {initialZoom} from '../src/data/constants';
test('waiting camera fits all marbles and goal on each map, including 0 and 300 participants',()=>{
 for(const stage of stages)for(const count of [0,1,30,100,300]){
  const f=waitingFrame(stage,count,'map',1600,900),halfHeight=900/initialZoom/f.zoom/2;
  const spawnTop=1-Math.max(0,Math.ceil(count/10)-5);
  assert.ok(Number.isFinite(f.zoom)&&f.zoom>0);
  assert.ok(f.center.y-halfHeight<=Math.min(0,spawnTop));assert.ok(f.center.y+halfHeight>=stage.goalY);
  assert.ok(waitingFrame(stage,count,'marbles',1600,900).zoom>=f.zoom);
 }
});
