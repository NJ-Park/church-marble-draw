import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Roulette} from '../src/roulette';
import {parseName} from '../src/utils/utils';
function fixture() {
  const g=Object.create(Roulette.prototype) as any;
  g._isRunning=true;g._renderer={width:1280,height:720};g._particleManager={shot(){}};g._recorder={stop(){}};
  g.dispatchEvent=(e:CustomEvent)=>{g.emitted=e.detail;};
  return g;
}
const marble=(id:string)=>({name:'동명이인',participantId:id});
test('last survivor is selected without needing the final marble to cross',()=>{
  const g=fixture();g._winnerRange={start:299,end:299};g._winners=Array.from({length:299},(_,i)=>marble(String(i)));g._marbles=[marble('299')];
  g._checkFinish();assert.deepEqual(g.emitted.participantIds,['299']);assert.equal(g._isRunning,false);
});
test('multiple last winners wait for ordered ranks; no premature selection with two remaining',()=>{
  const g=fixture();g._winnerRange={start:297,end:299};g._winners=Array.from({length:298},(_,i)=>marble(String(i)));g._marbles=[marble('298'),marble('299')];
  g._checkFinish();assert.equal(g.emitted,undefined);
  g._winners.push(g._marbles.shift());g._checkFinish();assert.deepEqual(g.emitted.participantIds,['297','298','299']);
});
test('literal participant adapter keeps one marble per identity with duplicate and syntax names',()=>{
  const g=fixture();g.setMarbles=(names:string[])=>{g._marbles=names.flatMap(n=>{const p=parseName(n)!;return Array.from({length:p.count},()=>({name:p.name}));});};
  const p=[{id:'a',name:'김*300/9'},{id:'b',name:'김*300/9'}];g.setParticipants(p);
  assert.equal(g._marbles.length,2);assert.deepEqual(g._marbles.map((m:any)=>m.participantId),['a','b']);assert.equal(g._marbles[0].name,'김*300/9');
});
