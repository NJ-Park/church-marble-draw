const fs = require('node:fs');
const { parseEnv } = require('node:util');

// Validate BEFORE Parcel can copy a key into a public JavaScript bundle.
function validate(env) {
  const url = env.CD_SUPABASE_URL || '', key = env.CD_SUPABASE_PUBLISHABLE_KEY || '';
  if (!url && !key) return;
  if (!url || !key) throw Error('Both Supabase URL and PUBLIC key are required.');
  const parsed = new URL(url);
  const local = env.CD_TEST_MODE === '1' && parsed.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(parsed.hostname);
  if ((parsed.protocol !== 'https:' && !local) || parsed.username || parsed.password) throw Error('Invalid Supabase URL.');
  if (key.startsWith('eyJ')) {
    let role;
    try { role = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()).role; } catch {}
    if (role !== 'anon') throw Error('Refusing non-anon JWT key in browser build.');
  } else if (!/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) throw Error('Refusing non-publishable key in browser build.');
  if (env.CD_TEST_MODE === '1' && !local) throw Error('Test builds must use a loopback API.');
  if (env.CD_PUBLIC_SITE_URL) {
    const site = new URL(env.CD_PUBLIC_SITE_URL);
    const localSite = local && site.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(site.hostname);
    if ((site.protocol !== 'https:' && !localSite) || site.username || site.password || !site.pathname.endsWith('/') || site.search || site.hash) throw Error('Site URL must be an HTTPS folder ending in /.');
  }
}
function configure() {
  const env = {};
  for (const file of ['.env', '.env.production', '.env.local', '.env.production.local']) {
    if (fs.existsSync(file)) Object.assign(env, parseEnv(fs.readFileSync(file, 'utf8')));
  }
  Object.assign(env, process.env);
  validate(env);
  for (const name of ['CD_SUPABASE_URL', 'CD_SUPABASE_PUBLISHABLE_KEY', 'CD_PUBLIC_SITE_URL', 'CD_TEST_MODE']) process.env[name] = env[name] || '';
}
module.exports = { validate, configure };
