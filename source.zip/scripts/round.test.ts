import { test } from 'node:test';
import assert from 'node:assert/strict';
import {prepareRound,completeRound,validateName, type Participant} from '../src/event/round';
const people:Participant[]=Array.from({length:300},(_,i)=>({id:String(i),name:i<2?'김민수':`참가자${i}`,excluded:false}));
const settings={id:'r1',mode:'first' as const,count:3,map:0,excludeWinners:true};
test('first/last use opposite rank ranges for 300 participants',()=>{
 assert.deepEqual(prepareRound(people,settings).winnerRange,{start:0,end:2});
 assert.deepEqual(prepareRound(people,{...settings,mode:'last'}).winnerRange,{start:297,end:299});
});
test('duplicate names stay independent; next round excludes winner IDs',()=>{
 const r=prepareRound(people,{...settings,count:1});
 const next=completeRound(r,['0'],people);
 assert.equal(next[0].excluded,true);assert.equal(next[1].excluded,false);
 assert.equal(prepareRound(next,settings).participants.length,299);
});
test('round snapshot stays fixed while roster changes',()=>{
 const p=structuredClone(people);const r=prepareRound(p,settings);p[0].name='바뀜';p.pop();
 assert.equal(r.participants.length,300);assert.equal(r.participants[0].name,'김민수');
});
test('names are literal, including count/weight syntax',()=>{
 assert.equal(validateName(' 김*300/9 '),'김*300/9');
 assert.throws(()=>validateName('  '));assert.throws(()=>validateName('김\u202e민수'));
});
test('invalid counts, IDs, mode, map and overflow are rejected',()=>{
 for(const count of [0,301,1.5,NaN]) assert.throws(()=>prepareRound(people,{...settings,count}));
 assert.throws(()=>prepareRound([...people,people[0]],settings));
 assert.throws(()=>prepareRound([{...people[0],excluded:true}],{...settings,count:1}));
 assert.throws(()=>prepareRound(people,{...settings,map:4}));
});
test('forged and duplicate results rejected; optional exclusion respected',()=>{
 const r=prepareRound(people,settings);
 for(const ids of [['x','1','2'],['1','1','2'],['1']]) assert.throws(()=>completeRound(r,ids,people));
 assert.equal(completeRound({...r,excludeWinners:false},['0','1','2'],people).filter(p=>p.excluded).length,0);
});
