/** Local QA only. In-memory SQL + minimal Auth/REST adapter, NOT a Supabase emulator.
 * Never deploy this script. No JWT verification or Realtime transport is implemented.
 * It binds loopback, accepts a fixed synthetic login, and shuts down after 30 minutes.
 */
import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {randomUUID} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
async function main(){
 const db=new PGlite(),root=resolve(process.argv[2]||'dist-cloud-test');
 await db.exec(`create schema auth;create role anon nologin;create role authenticated nologin;
 create table auth.users(id uuid primary key);
 create function auth.uid() returns uuid language sql stable as $$select (current_setting('request.jwt.claims',true)::jsonb->>'sub')::uuid$$;
 create function auth.jwt() returns jsonb language sql stable as $$select current_setting('request.jwt.claims',true)::jsonb$$;
 grant usage on schema auth,public to anon,authenticated;grant execute on all functions in schema auth to anon,authenticated;`);
 await db.exec(await readFile('supabase/migrations/202611130001_church_draw.sql','utf8'));
 await db.exec(await readFile('supabase/migrations/202611140001_delete_event.sql','utf8'));
 await db.exec(await readFile('supabase/migrations/202611140002_shuffle.sql','utf8'));
 const host=randomUUID();await db.query('insert into auth.users values($1)',[host]);
 type User={id:string;is_anonymous:boolean;aud:string;role:string;email?:string;created_at:string;app_metadata:object;user_metadata:object;identities:unknown[]};
 const sessions=new Map<string,{user:User;access_token:string;refresh_token:string;expires_in:number;expires_at:number;token_type:string}>();
 function session(id:string,anonymous:boolean){
  const user:User={id,is_anonymous:anonymous,aud:'authenticated',role:'authenticated',email:anonymous?undefined:'host@example.test',created_at:new Date().toISOString(),app_metadata:{provider:anonymous?'anonymous':'email'},user_metadata:{},identities:[]};
  const expires_at=Math.floor(Date.now()/1000)+3600;
  const jwt=[{alg:'HS256',typ:'JWT'},{sub:id,role:'authenticated',is_anonymous:anonymous,exp:expires_at},'local-qa-signature'].map(x=>Buffer.from(typeof x==='string'?x:JSON.stringify(x)).toString('base64url')).join('.');
  const result={user,access_token:jwt,refresh_token:randomUUID(),expires_in:3600,expires_at,token_type:'bearer'};sessions.set(jwt,result);return result;
 }
 let queue=Promise.resolve();
 const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.wasm':'application/wasm','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.txt':'text/plain'};
 const server=createServer((req,res)=>{
  queue=queue.then(async()=>{
   const url=new URL(req.url||'/', 'http://127.0.0.1:1237');
   const json=(status:number,data:unknown)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
   try{
    if(!url.pathname.startsWith('/auth/')&&!url.pathname.startsWith('/rest/')){
     const file=resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/cloud.html':url.pathname));
     if(!file.startsWith(root+sep)){json(403,{message:'Forbidden'});return;}
     if(!(await stat(file)).isFile()){json(404,{message:'Not found'});return;}
     res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(await readFile(file));return;
    }
    const chunks:Buffer[]=[];for await(const chunk of req)chunks.push(chunk);const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
    const current=sessions.get((req.headers.authorization||'').replace(/^Bearer /,''));
    await db.exec('reset role');
    if(url.pathname==='/auth/v1/signup'){
     const id=randomUUID();await db.query('insert into auth.users values($1)',[id]);json(200,session(id,true));return;
    }
    if(url.pathname==='/auth/v1/token'){
     if(url.searchParams.get('grant_type')==='password'&&body.email==='host@example.test'&&body.password==='local-test-only'){json(200,session(host,false));return;}
     json(400,{msg:'Synthetic QA login only',error_code:'invalid_credentials'});return;
    }
    if(url.pathname==='/auth/v1/user'){json(current?200:401,current?.user||{msg:'Unauthorized'});return;}
    if(url.pathname==='/auth/v1/logout'){if(current)sessions.delete(current.access_token);res.writeHead(204);res.end();return;}
    await db.query("select set_config('request.jwt.claims',$1,false)",[JSON.stringify({sub:current?.user.id??null,is_anonymous:current?.user.is_anonymous??true})]);
    await db.exec(current?'set role authenticated':'set role anon');
    if(url.pathname==='/rest/v1/cd_events'&&req.method==='GET'){
     json(200,(await db.query('select id,title from public.cd_events order by created_at desc')).rows);return;
    }
    const match=/^\/rest\/v1\/rpc\/(cd_[a-z_]+)$/.exec(url.pathname);
    if(match&&req.method==='POST'){
     const keys=Object.keys(body);if(keys.some(key=>!(/^[a-z_]+$/).test(key)))throw Error('Invalid argument');
     const result=await db.query<{value:unknown}>(`select public.${match[1]}(${keys.map((key,i)=>`${key} => $${i+1}`).join(',')}) as value`,keys.map(key=>body[key]));
     json(200,result.rows[0].value);return;
    }
    json(404,{message:'Not implemented in local QA adapter'});
   }catch(error){const e=error as {message:string;code?:string};json(e.code==='ENOENT'?404:400,{message:e.message,code:e.code||'LOCAL_QA_ERROR',details:null,hint:null});}
  }).catch(error=>{console.error('QA request failed',String(error));res.end();});
 });
 server.listen(1237,'127.0.0.1',()=>console.log('Local QA: http://127.0.0.1:1237/cloud.html (host@example.test / local-test-only). Expires in 30 minutes.'));
 let closing=false;async function close(){if(closing)return;closing=true;server.close();server.closeAllConnections();await queue;await db.close();process.exit(0);}
 setTimeout(()=>void close(),30*60*1000);process.on('SIGINT',()=>void close());process.on('SIGTERM',()=>void close());
}
void main();
