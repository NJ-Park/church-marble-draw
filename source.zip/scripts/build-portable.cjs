// Parcel's supported file cache avoids native mmap restrictions in sandboxed environments.
require('./cloud-config.cjs').configure();
const { createRequire } = require('node:module');
const parcelRequire = createRequire(require.resolve('parcel'));
const coreRequire = createRequire(parcelRequire.resolve('@parcel/core'));
const { Parcel } = parcelRequire('@parcel/core');
const { FSCache } = coreRequire('@parcel/cache');
const { NodeFS } = coreRequire('@parcel/fs');
const path = require('node:path');
const entries = process.argv.slice(2);
new Parcel({
  entries: entries.length ? entries : ['index.html'],
  defaultConfig: parcelRequire.resolve('@parcel/config-default'),
  mode: 'production',
  shouldAutoInstall: false,
  cache: new FSCache(new NodeFS(), path.resolve('.parcel-file-cache')),
  defaultTargetOptions: { distDir: path.resolve(process.env.EVENT_DIST || 'dist-local'), publicUrl: './' },
}).run().then(r => {
  const fs = require('node:fs');
  const out = path.resolve(process.env.EVENT_DIST || 'dist-local');
  for (const name of ['LICENSE', 'THIRD_PARTY_NOTICES.txt']) {
    if (fs.existsSync(name)) fs.copyFileSync(name, path.join(out, name));
  }
  if (entries.some(entry => path.basename(entry) === 'cloud.html')) {
    // Relative links also work when GitHub Pages serves /repository-name/.
    fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=./cloud.html"><title>교회 행사 구슬 추첨</title><p><a href="./cloud.html">진행자 화면으로 이동</a></p></html>\n');
    fs.writeFileSync(path.join(out, '.nojekyll'), '');
  }
  console.log(`Built ${r.bundleGraph.getBundles().length} bundles in ${r.buildTime}ms`);
  process.exit(0);
}).catch(e => { console.error(e.diagnostics || e); process.exit(1); });
