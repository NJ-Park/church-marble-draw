import { before, after, test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { PGlite } from '@electric-sql/pglite';
const db=new PGlite();
const host=randomUUID(), outsider=randomUUID(), display=randomUUID(), guest=randomUUID();
let eid:string,code:string,rid:string,token:string;
const sid=randomUUID(), requestKey=randomUUID();
async function identity(id:string|null,anonymous=true){
 await db.exec('reset role');
 await db.query("select set_config('request.jwt.claims',$1,false)",[JSON.stringify({sub:id,is_anonymous:anonymous})]);
 await db.exec(id?'set role authenticated':'set role anon');
}
async function rpc<T=any>(name:string,args:unknown[]=[]):Promise<T>{
 const r=await db.query<{value:T}>(`select public.${name}(${args.map((_,i)=>`$${i+1}`).join(',')}) as value`,args);return r.rows[0].value;
}
before(async()=>{
 await db.exec(`create schema auth; create role anon nologin; create role authenticated nologin;
 create table auth.users(id uuid primary key);
 create function auth.uid() returns uuid language sql stable as $$select (current_setting('request.jwt.claims',true)::jsonb->>'sub')::uuid$$;
 create function auth.jwt() returns jsonb language sql stable as $$select current_setting('request.jwt.claims',true)::jsonb$$;
 grant usage on schema auth,public to anon,authenticated; grant execute on all functions in schema auth to anon,authenticated;`);
 for(const id of [host,outsider,display,guest])await db.query('insert into auth.users values($1)',[id]);
 await db.exec(readFileSync('supabase/migrations/202611130001_church_draw.sql','utf8'));
 await db.exec(readFileSync('supabase/migrations/202611140001_delete_event.sql','utf8'));
 await db.exec(readFileSync('supabase/migrations/202611140002_shuffle.sql','utf8'));
 await db.exec(readFileSync('supabase/migrations/202611140003_live_lobby.sql','utf8'));
});
after(async()=>{await db.close();});
test('anonymous sessions cannot create or inspect host events',async()=>{
 await identity(guest);await assert.rejects(rpc('cd_create_event',['forbidden',300]),/HOST_LOGIN_REQUIRED/);
 await identity(host,false);eid=await rpc('cd_create_event',['교회 테스트',300]);
 const snapshot=await rpc('cd_host_snapshot',[eid]);code=snapshot.joinCode;
 await identity(outsider,false);await assert.rejects(rpc('cd_host_snapshot',[eid]),/FORBIDDEN/);
 assert.equal((await db.query('select * from public.cd_events')).rows.length,0);
 await assert.rejects(db.query('select * from cd_private.participants'),/permission denied/);
});
test('public QR lookup reveals event metadata, not roster; no unauthenticated writes',async()=>{
 await identity(null);const info=await rpc('cd_event_info',[code]);assert.equal(info.title,'교회 테스트');assert.equal(info.participants,undefined);
 await assert.rejects(rpc('cd_register',[code,'김민수']),/permission denied/);
});
test('same subject registers once; literal syntax and duplicate names remain separate',async()=>{
 await identity(guest);const p=await rpc('cd_register',[code,'김*300/9']);const retry=await rpc('cd_register',[code,'바뀐이름']);assert.equal(retry.id,p.id);assert.equal(retry.name,'김*300/9');
 await identity(outsider);await rpc('cd_register',[code,'김*300/9']);
 await identity(host,false);const s=await rpc('cd_host_snapshot',[eid]);assert.equal(s.participants.length,2);assert.notEqual(s.participants[0].id,s.participants[1].id);
});
test('client cannot mutate event table or privileged RPCs',async()=>{
 await identity(guest);await assert.rejects(db.query('update public.cd_events set capacity=1 where id=$1',[eid]),/permission denied/);
 await assert.rejects(rpc('cd_set_registration',[eid,false]),/FORBIDDEN/);
 await assert.rejects(rpc('cd_rotate_display',[eid]),/FORBIDDEN/);
});
test('imports are atomic, idempotent, validated and capacity bounded',async()=>{
 await identity(host,false);const key=randomUUID(),names=Array.from({length:297},(_,i)=>`참가자${i+3}`);
 await rpc('cd_import',[eid,key,names]);await rpc('cd_import',[eid,key,names]);
 await assert.rejects(rpc('cd_import',[eid,key,['다른 요청']]),/REQUEST_CONFLICT/);
 assert.equal((await rpc('cd_host_snapshot',[eid])).participants.length,299);
 await assert.rejects(rpc('cd_import',[eid,randomUUID(),['정상','초과']]),/CAPACITY_REACHED/);
 await assert.rejects(rpc('cd_import',[eid,randomUUID(),['\u202e변조']]),/INVALID_NAME/);
 assert.equal((await rpc('cd_host_snapshot',[eid])).participants.length,299);
});
test('300th registration succeeds; 301st is rejected by DB',async()=>{
 const a=randomUUID(),b=randomUUID();await db.exec('reset role');for(const id of [a,b])await db.query('insert into auth.users values($1)',[id]);
 await identity(a);assert.equal((await rpc('cd_register',[code,'300번째'])).number,300);
 await identity(b);await assert.rejects(rpc('cd_register',[code,'301번째']),/CAPACITY_REACHED/);
});
test('closed registration rejects new participants but permits idempotent retry',async()=>{
 await identity(host,false);await rpc('cd_set_registration',[eid,false]);await identity(guest);assert.equal((await rpc('cd_register',[code,'다시'])).existing,true);
 const fresh=randomUUID();await db.exec('reset role');await db.query('insert into auth.users values($1)',[fresh]);await identity(fresh);
 await assert.rejects(rpc('cd_register',[code,'늦음']),/REGISTRATION_CLOSED/);
});
test('display pairing is one use and does not grant host access',async()=>{
 await identity(host,false);const pair=await rpc('cd_rotate_display',[eid]);await identity(display);await rpc('cd_pair_display',[eid,pair]);
 await assert.rejects(rpc('cd_pair_display',[eid,pair]),/INVALID_PAIR_CODE/);
 await assert.rejects(rpc('cd_host_snapshot',[eid]),/FORBIDDEN/);
 await rpc('cd_heartbeat',[eid,sid]);assert.ok((await rpc('cd_display_snapshot',[eid])).event);
});
test('one active round; retry preserves snapshot and rejects changed settings',async()=>{
 await identity(host,false);rid=await rpc('cd_prepare',[eid,requestKey,'first',1,0,true]);
 assert.equal(await rpc('cd_prepare',[eid,requestKey,'first',1,0,true]),rid);
 await assert.rejects(rpc('cd_prepare',[eid,requestKey,'last',1,0,true]),/REQUEST_CONFLICT/);
 await assert.rejects(rpc('cd_prepare',[eid,randomUUID(),'first',1,0,true]),/ROUND_ACTIVE/);
 const s=await rpc('cd_host_snapshot',[eid]);assert.equal(s.rounds[0].entries.length,300);
 await assert.rejects(rpc('cd_exclude',[eid,s.participants[0].id,true]),/ROUND_ACTIVE/);
});
test('one renderer claims round; version and session are checked',async()=>{
 await identity(display);await assert.rejects(rpc('cd_claim',[eid,rid,sid,'bad']),/ENGINE_VERSION_MISMATCH/);
 await assert.rejects(rpc('cd_claim',[eid,rid,sid,null]),/ENGINE_VERSION_MISMATCH/);
 token=await rpc('cd_claim',[eid,rid,sid,'e9a9d22-event-v3']);assert.equal(await rpc('cd_claim',[eid,rid,sid,'e9a9d22-event-v3']),token);
 await assert.rejects(rpc('cd_claim',[eid,rid,randomUUID(),'e9a9d22-event-v3']),/ROUND_ALREADY_CLAIMED/);
});
test('result validates actor, execution token, count, membership and duplicates',async()=>{
 await identity(display);const s=await rpc('cd_display_snapshot',[eid]);const winner=s.round.entries[0].id;
 await assert.rejects(rpc('cd_finish',[eid,rid,sid,randomUUID(),[winner]]),/EXECUTION_FORBIDDEN/);
 await assert.rejects(rpc('cd_finish',[eid,rid,sid,token,[randomUUID()]]),/INVALID_WINNERS/);
 await assert.rejects(rpc('cd_finish',[eid,rid,sid,token,[winner,winner]]),/INVALID_WINNERS/);
 await identity(guest);await assert.rejects(rpc('cd_finish',[eid,rid,sid,token,[winner]]),/DISPLAY_FORBIDDEN/);
 await identity(display);await rpc('cd_finish',[eid,rid,sid,token,[winner]]);await rpc('cd_finish',[eid,rid,sid,token,[winner]]);
 await assert.rejects(rpc('cd_finish',[eid,rid,sid,token,[s.round.entries[1].id]]),/RESULT_CONFLICT/);
 await identity(host,false);const h=await rpc('cd_host_snapshot',[eid]);assert.equal(h.participants.filter((p:any)=>p.excluded).length,1);assert.equal(h.rounds[0].status,'completed');
});
test('next last-survivor round snapshots 299; cancellation prevents late results',async()=>{
 await identity(display);await rpc('cd_heartbeat',[eid,sid]);await identity(host,false);
 const next=await rpc<string>('cd_prepare',[eid,randomUUID(),'last',2,3,true]);assert.equal((await rpc('cd_host_snapshot',[eid])).rounds[0].entries.length,299);
 await identity(display);const t=await rpc('cd_claim',[eid,next,sid,'e9a9d22-event-v3']);const s=await rpc('cd_display_snapshot',[eid]);
 await identity(host,false);await rpc('cd_cancel',[eid,next]);await identity(display);
 await assert.rejects(rpc('cd_finish',[eid,next,sid,t,s.round.entries.slice(0,2).map((p:any)=>p.id)]),/LEASE_EXPIRED_OR_CANCELLED/);
});
test('expired execution cannot revive or persist a result',async()=>{
 await identity(display);await rpc('cd_heartbeat',[eid,sid]);await identity(host,false);const r=await rpc<string>('cd_prepare',[eid,randomUUID(),'first',1,0,false]);
 await identity(display);const t=await rpc('cd_claim',[eid,r,sid,'e9a9d22-event-v3']);const s=await rpc('cd_display_snapshot',[eid]);
 await db.exec('reset role');await db.query("update cd_private.rounds set lease_until=now()-interval '1 second' where id=$1",[r]);
 await identity(display);await assert.rejects(rpc('cd_finish',[eid,r,sid,t,[s.round.entries[0].id]]),/LEASE_EXPIRED_OR_CANCELLED/);
 assert.equal(await rpc('cd_heartbeat',[eid,sid]),false);assert.equal((await rpc('cd_display_snapshot',[eid])).round.status,'interrupted');
});
test('rotating pairing revokes former display access',async()=>{
 await identity(host,false);await rpc('cd_rotate_display',[eid]);await identity(display);await assert.rejects(rpc('cd_display_snapshot',[eid]),/DISPLAY_FORBIDDEN/);
 assert.equal((await db.query('select * from public.cd_events')).rows.length,0);
});
test('event deletion requires owner, exact title and no active round; cascades only target event',async()=>{
 await identity(host,false);const target=await rpc<string>('cd_create_event',['삭제 검증',300]);
 const info=await rpc('cd_host_snapshot',[target]);const joinCode=info.joinCode;
 await rpc('cd_import',[target,randomUUID(),['테스트 참가자']]);
 const pair=await rpc('cd_rotate_display',[target]);
 await identity(display);await rpc('cd_pair_display',[target,pair]);await rpc('cd_heartbeat',[target,sid]);
 await assert.rejects(rpc('cd_delete_event',[target,'삭제 검증']),/FORBIDDEN/);
 await identity(null);await assert.rejects(rpc('cd_delete_event',[target,'삭제 검증']),/permission denied/);
 await identity(outsider,false);await assert.rejects(rpc('cd_delete_event',[target,'삭제 검증']),/FORBIDDEN/);
 await identity(host,false);await assert.rejects(rpc('cd_delete_event',[target,'잘못된 이름']),/CONFIRM_TITLE_MISMATCH/);
 await assert.rejects(rpc('cd_delete_event',[target,null]),/CONFIRM_TITLE_MISMATCH/);
 const round=await rpc<string>('cd_prepare',[target,randomUUID(),'first',1,0,true]);
 await assert.rejects(rpc('cd_delete_event',[target,'삭제 검증']),/ROUND_ACTIVE/);
 await identity(display);await rpc('cd_claim',[target,round,sid,'e9a9d22-event-v3']);
 await identity(host,false);await assert.rejects(rpc('cd_delete_event',[target,'삭제 검증']),/ROUND_ACTIVE/);
 await rpc('cd_cancel',[target,round]);await rpc('cd_delete_event',[target,'삭제 검증']);
 await assert.rejects(rpc('cd_event_info',[joinCode]),/EVENT_NOT_FOUND/);
 assert.equal((await rpc('cd_host_snapshot',[eid])).participants.length,300);
 await identity(display);await assert.rejects(rpc('cd_display_snapshot',[target]),/DISPLAY_FORBIDDEN/);
 await db.exec('reset role');
 for(const table of ['secrets','displays','participants','rounds','imports','audit']){
  assert.equal((await db.query(`select * from cd_private.${table} where event_id=$1`,[target])).rows.length,0);
 }
 assert.equal((await db.query('select * from public.cd_events where id=$1',[target])).rows.length,0);
});
test('shuffle preview preserves identities, retries, freezes the start layout and blocks active reshuffles',async()=>{
 await identity(host,false);const target=await rpc<string>('cd_create_event',['섞기 검증',300]);
 await rpc('cd_import',[target,randomUUID(),Array.from({length:300},(_,i)=>i<2?'동명이인':`참가자 ${i}`)]);
 await identity(guest);await assert.rejects(rpc('cd_shuffle',[target,randomUUID(),0]),/FORBIDDEN/);
 await identity(host,false);const request=randomUUID();const previewId=await rpc('cd_shuffle',[target,request,2]);
 let snapshot=await rpc('cd_host_snapshot',[target]);const preview=snapshot.preview;
 assert.equal(preview.id,previewId);assert.equal(preview.valid,true);assert.equal(preview.entries.length,300);
 assert.deepEqual([...preview.entries].sort((a:any,b:any)=>a.number-b.number),snapshot.participants.map(({excluded,...p}:any)=>p));
 assert.equal(await rpc('cd_shuffle',[target,request,2]),previewId);
 assert.deepEqual((await rpc('cd_host_snapshot',[target])).preview.entries,preview.entries);
 await assert.rejects(rpc('cd_shuffle',[target,request,1]),/REQUEST_CONFLICT/);
 const pair=await rpc('cd_rotate_display',[target]);await identity(display);await rpc('cd_pair_display',[target,pair]);await rpc('cd_heartbeat',[target,sid]);
 assert.deepEqual((await rpc('cd_display_snapshot',[target])).preview.entries,preview.entries);
 await identity(host,false);
 await assert.rejects(rpc('cd_prepare',[target,randomUUID(),'first',1,1,true]),/SHUFFLE_STALE/);
 const excludedId=preview.entries[0].id;await rpc('cd_exclude',[target,excludedId,true]);
 assert.equal((await rpc('cd_host_snapshot',[target])).preview.valid,false);
 await assert.rejects(rpc('cd_prepare',[target,randomUUID(),'first',1,2,true]),/SHUFFLE_STALE/);
 await rpc('cd_shuffle',[target,randomUUID(),2]);snapshot=await rpc('cd_host_snapshot',[target]);
 assert.equal(snapshot.preview.entries.length,299);assert.ok(snapshot.preview.entries.every((p:any)=>p.id!==excludedId));
 const startKey=randomUUID(),round=await rpc('cd_prepare',[target,startKey,'first',1,2,true]);
 const state=await rpc('cd_host_snapshot',[target]);assert.equal(state.preview,null);
 assert.deepEqual(state.rounds[0].entries,snapshot.preview.entries);assert.equal(state.rounds[0].engineVersion,'e9a9d22-event-v3');
 assert.equal(await rpc('cd_prepare',[target,startKey,'first',1,2,true]),round);
 await assert.rejects(rpc('cd_shuffle',[target,randomUUID(),2]),/ROUND_ACTIVE/);
 await rpc('cd_cancel',[target,round]);await rpc('cd_shuffle',[target,randomUUID(),2]);await rpc('cd_delete_event',[target,'섞기 검증']);
 await db.exec('reset role');assert.equal((await db.query('select * from cd_private.previews where event_id=$1',[target])).rows.length,0);
});
test('paired display receives live waiting roster and map, including additions after shuffle',async()=>{
 await identity(host,false);const target=await rpc<string>('cd_create_event',['실시간 대기 검증',300]);
 await rpc('cd_import',[target,randomUUID(),['첫째','둘째']]);
 const hostState=await rpc('cd_host_snapshot',[target]);const code=hostState.joinCode;
 const pair=await rpc('cd_rotate_display',[target]);
 await identity(display);await rpc('cd_pair_display',[target,pair]);
 let s=await rpc('cd_display_snapshot',[target]);assert.equal(s.joinCode,code);assert.equal(s.event.registration_open,true);assert.equal(s.lobby.entries.length,2);assert.equal(s.lobby.map,0);assert.equal(s.round,null);
 await identity(guest);await assert.rejects(rpc('cd_display_snapshot',[target]),/DISPLAY_FORBIDDEN/);
 await assert.rejects(rpc('cd_set_map',[target,2]),/FORBIDDEN/);
 await identity(host,false);await rpc('cd_set_registration',[target,false]);
 await identity(display);assert.equal((await rpc('cd_display_snapshot',[target])).event.registration_open,false);
 await identity(host,false);await rpc('cd_set_registration',[target,true]);
 await identity(display);assert.equal((await rpc('cd_display_snapshot',[target])).event.registration_open,true);
 await identity(host,false);await rpc('cd_set_map',[target,2]);await rpc('cd_shuffle',[target,randomUUID(),2]);
 await identity(display);const before=(await rpc('cd_display_snapshot',[target])).lobby;assert.equal(before.map,2);
 await identity(guest);const joined=await rpc('cd_register',[code,'새 참가자']);
 await identity(display);s=await rpc('cd_display_snapshot',[target]);
 assert.equal(s.preview.valid,false);assert.equal(s.lobby.entries.length,3);assert.deepEqual(s.lobby.entries.slice(0,2),before.entries);assert.equal(s.lobby.entries[2].id,joined.id);
 await identity(host,false);await rpc('cd_exclude',[target,before.entries[0].id,true]);
 await identity(display);s=await rpc('cd_display_snapshot',[target]);assert.equal(s.lobby.entries.length,2);assert.ok(s.lobby.entries.every((p:any)=>p.id!==before.entries[0].id));
 await identity(host,false);await rpc('cd_set_map',[target,3]);await rpc('cd_shuffle',[target,randomUUID(),3]);
 await identity(display);await rpc('cd_heartbeat',[target,sid]);
 await identity(host,false);const round=await rpc('cd_prepare',[target,randomUUID(),'first',1,3,false]);
 await assert.rejects(rpc('cd_set_map',[target,0]),/ROUND_ACTIVE/);
 const frozen=(await rpc('cd_host_snapshot',[target])).rounds[0].entries;
 const fresh=randomUUID();await db.exec('reset role');await db.query('insert into auth.users values($1)',[fresh]);await identity(fresh);await rpc('cd_register',[code,'추첨 중 등록']);
 await identity(display);s=await rpc('cd_display_snapshot',[target]);assert.equal(s.lobby.entries.length,3);assert.deepEqual(s.round.entries,frozen);
 await identity(host,false);await rpc('cd_cancel',[target,round]);await rpc('cd_delete_event',[target,'실시간 대기 검증']);
});
